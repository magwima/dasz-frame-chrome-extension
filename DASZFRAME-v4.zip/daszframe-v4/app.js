/* DASZFRAME Photo Studio v4.0
   Removed: video export, animation timeline
   Added: Spotlight Image Selector, Daszage Composite Editor
   Multiple photo layers · per-layer styles · cinematic grades · color grading
   LUT support · curves · film looks · effects */
'use strict';
const {createElement:h,useState,useRef,useEffect,useCallback,useMemo,Fragment}=React;

// ══════════════════════════════════════════════════════════════════════════════
// CONSTANTS
// ══════════════════════════════════════════════════════════════════════════════

const LAYOUT_MODES=[
  {id:'dasz',label:'DASZ',icon:'◉',sig:true},
  {id:'mosaic',label:'Mosaic',icon:'▦'},{id:'editorial',label:'Editorial',icon:'◈'},
  {id:'cubist',label:'Cubist',icon:'◇'},{id:'symmetry',label:'Symmetry',icon:'⊞'},
  {id:'gallery',label:'Gallery',icon:'⊡'},{id:'experimental',label:'Exp',icon:'✦'},
];

const FILM_LOOKS=[
  {id:'none',      name:'None',          sub:'No grade applied'},
  {id:'cinematic', name:'Cinematic',     sub:'Filmic contrast · soft highlights'},
  {id:'vintage',   name:'Vintage Film',  sub:'Grain · warm tones · film fade'},
  {id:'bw',        name:'Black & White', sub:'High contrast monochrome'},
  {id:'noir',      name:'Film Noir',     sub:'Deep shadows · dramatic contrast'},
  {id:'bleach',    name:'Bleach Bypass', sub:'Desaturated · strong contrast'},
  {id:'teal',      name:'Teal & Orange', sub:'Hollywood blockbuster grading'},
  {id:'editorial', name:'Editorial',     sub:'Fashion-magazine · clean tones'},
  {id:'kodak',     name:'Kodak Style',   sub:'Warm shadows · rich tones'},
  {id:'fuji',      name:'Fuji Style',    sub:'Cool midtones · fine grain'},
  {id:'documentary',name:'Documentary', sub:'Natural · slightly desaturated'},
  {id:'halftone',  name:'Halftone',      sub:'Print effect · graphic'},
];

const FACE_REGIONS=[
  {id:'leftEye',   label:'Left Eye',   area:{x:.18,y:.26,w:.24,h:.16}},
  {id:'rightEye',  label:'Right Eye',  area:{x:.58,y:.26,w:.24,h:.16}},
  {id:'nose',      label:'Nose',       area:{x:.35,y:.42,w:.30,h:.20}},
  {id:'mouth',     label:'Mouth',      area:{x:.26,y:.62,w:.48,h:.18}},
  {id:'leftCheek', label:'Left Cheek', area:{x:.04,y:.38,w:.28,h:.28}},
  {id:'rightCheek',label:'Right Cheek',area:{x:.68,y:.38,w:.28,h:.28}},
  {id:'forehead',  label:'Forehead',   area:{x:.14,y:.04,w:.72,h:.22}},
  {id:'chin',      label:'Chin',       area:{x:.28,y:.80,w:.44,h:.18}},
  {id:'leftHalf',  label:'Left Half',  area:{x:.00,y:.00,w:.50,h:1.0}},
  {id:'rightHalf', label:'Right Half', area:{x:.50,y:.00,w:.50,h:1.0}},
  {id:'topStrip',  label:'Top Strip',  area:{x:.00,y:.00,w:1.0,h:.34}},
  {id:'midStrip',  label:'Mid Strip',  area:{x:.00,y:.34,w:1.0,h:.33}},
  {id:'botStrip',  label:'Bot Strip',  area:{x:.00,y:.67,w:1.0,h:.33}},
];

const BLEND_MODES=['normal','multiply','screen','overlay','darken','lighten','color-dodge','color-burn','hard-light','soft-light','difference','exclusion','hue','saturation','color','luminosity'];

// Depth (world z; larger = farther from camera) per face region, for the 3D
// dolly-zoom. Eyes sit on the focus plane; nose nearest; halves/strips behind.
const FOCUS_Z=10;
const FACE_DEPTH={
  'Nose':7.5,'Mouth':9,'Chin':9.4,
  'Left Eye':10,'Right Eye':10,
  'Left Cheek':10.6,'Right Cheek':10.6,'Forehead':10.9,
  'Left Half':12,'Right Half':12,
  'Top Strip':12.6,'Mid Strip':11.5,'Bot Strip':12.6,
};

const CANVAS_SIZES=[
  {id:'sq_sm',label:'Square SM',  w:480, h:480},
  {id:'sq_md',label:'Square MD',  w:640, h:640},
  {id:'sq_lg',label:'Square LG',  w:800, h:800},
  {id:'port', label:'Portrait',   w:540, h:720},
  {id:'story',label:'Story 9:16', w:405, h:720},
  {id:'land', label:'Landscape',  w:854, h:480},
];

const AI_QUICK=[
  {id:'museum',  icon:'🏛',label:'Museum',    look:'cinematic',layout:'gallery'},
  {id:'fashion', icon:'✦', label:'Fashion',   look:'editorial', layout:'editorial'},
  {id:'noir',    icon:'◼', label:'Noir',      look:'noir',      layout:'dasz'},
  {id:'surreal', icon:'◈', label:'Surreal',   look:'bleach',    layout:'cubist'},
  {id:'press',   icon:'▧', label:'Vintage',   look:'vintage',   layout:'mosaic'},
  {id:'pop',     icon:'⬡', label:'Pop Art',   look:'teal',      layout:'symmetry'},
];

// Default grade state for a new layer
const defaultGrade=()=>({
  exposure:0, contrast:0, highlights:0, shadows:0,
  whites:0, blacks:0, saturation:0, vibrance:0,
  temperature:0, tint:0, gamma:1, gain:1, lift:0,
  clarity:0, sharpness:0,
  look:'none', lookStrength:100,
  vignette:0, grain:0, chromAb:0, blur:0, glow:0,
  blendMode:'normal', opacity:100,
  visible:true, locked:false,
  borderRadius:0, borderStyle:'none', borderWidth:3,
  rotation:0,
  // Curve control points [0-255] for RGB master
  curvePoints:[[0,0],[64,64],[128,128],[192,192],[255,255]],
  // LUT
  lutName:null, lutData:null,
});

// ══════════════════════════════════════════════════════════════════════════════
// UTILS
// ══════════════════════════════════════════════════════════════════════════════
const uid=()=>Math.random().toString(36).slice(2,9);
const tick=()=>new Promise(r=>setTimeout(r,16));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,t)=>a+(b-a)*t;

function extractFragment(imgEl,region,size=400){
  const c=document.createElement('canvas');c.width=size;c.height=size;
  c.getContext('2d').drawImage(imgEl,region.x*imgEl.naturalWidth,region.y*imgEl.naturalHeight,
    region.w*imgEl.naturalWidth,region.h*imgEl.naturalHeight,0,0,size,size);
  return c.toDataURL('image/jpeg',.92);
}
const extractThumb=(imgEl,region)=>extractFragment(imgEl,region,80);

// Serialize a loaded <img> to a data URL so projects survive a page reload
// (blob: URLs do not). JPEG keeps file size reasonable; PNG would be huge.
function imgElToDataURL(imgEl,mime,q){
  if(!imgEl||!imgEl.naturalWidth) return null;
  const c=document.createElement('canvas');
  c.width=imgEl.naturalWidth;c.height=imgEl.naturalHeight;
  c.getContext('2d').drawImage(imgEl,0,0);
  try{return c.toDataURL(mime||'image/jpeg',q!=null?q:0.9);}catch(_){return null;}
}

// ── Film look → CSS filter string ────────────────────────────────────────────
function lookToFilter(look){
  switch(look){
    case 'cinematic':  return 'contrast(1.18) saturate(.72) brightness(.95)';
    case 'vintage':    return 'sepia(.45) brightness(1.08) contrast(.92) saturate(.85)';
    case 'bw':         return 'grayscale(1) contrast(1.15)';
    case 'noir':       return 'grayscale(1) contrast(1.45) brightness(.82)';
    case 'bleach':     return 'contrast(1.35) saturate(.38) brightness(1.05)';
    case 'teal':       return 'contrast(1.12) saturate(1.2) hue-rotate(8deg) brightness(.97)';
    case 'editorial':  return 'contrast(1.06) brightness(1.04) saturate(.88)';
    case 'kodak':      return 'sepia(.22) contrast(1.08) saturate(1.12) brightness(1.02)';
    case 'fuji':       return 'contrast(1.05) saturate(.95) brightness(1.02) hue-rotate(-5deg)';
    case 'documentary':return 'contrast(1.04) saturate(.82) brightness(.98)';
    case 'halftone':   return 'contrast(2.2) grayscale(1)';
    default: return 'none';
  }
}

// ── Grade → CSS filter (real-time preview via CSS) ────────────────────────────
function gradeToFilter(g){
  if(!g) return 'none';
  const br=clamp(1+(g.exposure||0)/100,.1,3);
  const ct=clamp(1+(g.contrast||0)/100,.1,3);
  const sat=clamp(1+(g.saturation||0)/100,0,3);
  const lkF=g.look&&g.look!=='none'?lookToFilter(g.look):'';
  let f=`brightness(${br}) contrast(${ct}) saturate(${sat})`;
  if(g.temperature>0) f+=` sepia(${g.temperature*.003})`;
  if(g.temperature<0) f+=` hue-rotate(${g.temperature*.1}deg)`;
  if(g.blur>0) f+=` blur(${g.blur*.04}px)`;
  return f.trim();
}

// ── Apply pixel-level grade to canvas (for export) ───────────────────────────
function applyGradePixels(ctx,W,H,g){
  if(!g||!W||!H) return;
  const id=ctx.getImageData(0,0,W,H);
  const d=id.data;
  const exp=Math.pow(2,(g.exposure||0)/100);
  const gamma=g.gamma||1;
  const lift=(g.lift||0)/255;
  const gain=g.gain||1;
  const sat=(g.saturation||0)/100;
  const temp=(g.temperature||0)/100;
  const tint=(g.tint||0)/100;
  const hi=(g.highlights||0)/100;
  const sh=(g.shadows||0)/100;
  // Build lookup tables for performance
  const lut=new Uint8Array(256);
  for(let i=0;i<256;i++){
    let v=i/255;
    v=Math.pow(v,1/gamma);
    v=v*gain+lift;
    v=v*exp;
    // Highlights/shadows
    if(v>.5) v=v+hi*(1-v)*2;
    else v=v+sh*v*2;
    lut[i]=clamp(Math.round(v*255),0,255);
  }
  for(let i=0;i<d.length;i+=4){
    let r=lut[d[i]],gv=lut[d[i+1]],b=lut[d[i+2]];
    // Saturation
    if(sat!==0){const lm=.299*r+.587*gv+.114*b;r=clamp(lm+(r-lm)*(1+sat),0,255);gv=clamp(lm+(gv-lm)*(1+sat),0,255);b=clamp(lm+(b-lm)*(1+sat),0,255);}
    // Temperature (warm/cool)
    if(temp>0){r=clamp(r+temp*30,0,255);b=clamp(b-temp*20,0,255);}
    else if(temp<0){b=clamp(b-temp*30,0,255);r=clamp(r+temp*20,0,255);}
    // Tint (green ↔ magenta). +tint = magenta (less green), −tint = green (more green)
    if(tint!==0) gv=clamp(gv-tint*20,0,255);
    d[i]=r;d[i+1]=gv;d[i+2]=b;
  }
  ctx.putImageData(id,0,0);
}

// ── Vignette overlay ─────────────────────────────────────────────────────────
function drawVignette(ctx,W,H,strength){
  if(!strength) return;
  const grad=ctx.createRadialGradient(W/2,H/2,Math.min(W,H)*.3,W/2,H/2,Math.max(W,H)*.75);
  grad.addColorStop(0,'rgba(0,0,0,0)');
  grad.addColorStop(1,`rgba(0,0,0,${strength/100})`);
  ctx.save();ctx.globalCompositeOperation='multiply';
  ctx.fillStyle=grad;ctx.fillRect(0,0,W,H);ctx.restore();
}

// ── Film grain overlay ────────────────────────────────────────────────────────
function drawGrain(ctx,W,H,amount){
  if(!amount) return;
  const id=ctx.getImageData(0,0,W,H);const d=id.data;
  const a=amount/100;
  for(let i=0;i<d.length;i+=4){const n=(Math.random()-.5)*a*80;d[i]=clamp(d[i]+n,0,255);d[i+1]=clamp(d[i+1]+n,0,255);d[i+2]=clamp(d[i+2]+n,0,255);}
  ctx.putImageData(id,0,0);
}

// ── Chromatic aberration ──────────────────────────────────────────────────────
function drawChromAb(ctx,W,H,amount){
  if(!amount||amount<1) return;
  const off=Math.round(amount*.5);
  const id=ctx.getImageData(0,0,W,H);
  const out=new ImageData(W,H);
  const s=id.data,t=out.data;
  for(let y=0;y<H;y++){for(let x=0;x<W;x++){
    const i=(y*W+x)*4;
    const ri=Math.min((y*W+Math.min(x+off,W-1))*4,s.length-4);
    const bi=Math.min((y*W+Math.max(x-off,0))*4,s.length-4);
    t[i]=s[ri];t[i+1]=s[i+1];t[i+2]=s[bi+2];t[i+3]=s[i+3];
  }}
  ctx.putImageData(out,0,0);
}

// ── Glow effect ───────────────────────────────────────────────────────────────
function drawGlow(ctx,W,H,amount){
  if(!amount) return;
  ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=amount/200;
  ctx.filter=`blur(${amount*.3}px)`;ctx.drawImage(ctx.canvas,0,0,W,H);
  ctx.filter='none';ctx.restore();
}

// ── LUT parser (.cube) ────────────────────────────────────────────────────────
function parseCube(text){
  const lines=text.split('\n').filter(l=>l.trim()&&!l.startsWith('#'));
  let size=17;const data=[];
  for(const line of lines){
    if(line.startsWith('LUT_3D_SIZE')){size=parseInt(line.split(' ')[1]);continue;}
    const vals=line.trim().split(/\s+/).map(Number);
    if(vals.length===3&&!isNaN(vals[0])) data.push(vals);
  }
  return{size,data};
}
function applyLUT(ctx,W,H,lut){
  if(!lut||!lut.data||!lut.data.length) return;
  const id=ctx.getImageData(0,0,W,H);const d=id.data;
  const s=lut.size;
  for(let i=0;i<d.length;i+=4){
    const r=d[i]/255*(s-1),g=d[i+1]/255*(s-1),b=d[i+2]/255*(s-1);
    const ri=Math.floor(r),gi=Math.floor(g),bi=Math.floor(b);
    const rf=r-ri,gf=g-gi,bf=b-bi;
    const idx=(bi*s*s+gi*s+ri);
    if(idx<lut.data.length){
      const [nr,ng,nb]=lut.data[Math.min(idx,lut.data.length-1)];
      d[i]=clamp(Math.round(nr*255),0,255);
      d[i+1]=clamp(Math.round(ng*255),0,255);
      d[i+2]=clamp(Math.round(nb*255),0,255);
    }
  }
  ctx.putImageData(id,0,0);
}

// ── Decoded-image cache (avoids re-decoding fragment dataURLs every frame) ────
const _imgCache=new Map();
function getImg(src){
  return new Promise(res=>{
    if(!src){res(null);return;}
    const c=_imgCache.get(src);
    if(c){res(c);return;}
    const img=new Image();
    img.onload=()=>{_imgCache.set(src,img);res(img);};
    img.onerror=()=>res(null);
    img.src=src;
  });
}

// ── Unified compositor — single source of truth for still + video export ──────
// Draws all visible layers onto ctx at `scale`, at animation time `timeMs`.
// Mirrors the on-canvas preview (grade + look via canvas filter) and adds the
// export-only optical FX. Fixes vs. the old exporter: collage/solid layers are
// now graded & drawn, photo layer transform (x/y/w/h/rotation) is honoured, and
// per-fragment animation is applied.
async function drawComposite(ctx,scale,layers,opts){
  const {CW,CH,bgColor,timeMs=0}=opts;
  ctx.save();
  ctx.setTransform(scale,0,0,scale,0,0);
  ctx.fillStyle=bgColor;ctx.fillRect(0,0,CW,CH);

  const vis=layers.filter(l=>l.visible!==false);
  for(const l of vis){
    const g=l.grade||defaultGrade();
    const combined=[gradeToFilter(g),(g.look&&g.look!=='none')?lookToFilter(g.look):'']
      .filter(s=>s&&s!=='none').join(' ')||'none';

    const lc=document.createElement('canvas');lc.width=CW;lc.height=CH;
    const lctx=lc.getContext('2d');

    if(l.type==='photo'&&l.imgEl){
      lctx.save();lctx.filter=combined;
      const x=l.x||0,y=l.y||0,w=l.w||CW,hh=l.h||CH,cx=x+w/2,cy=y+hh/2;
      lctx.translate(cx,cy);lctx.rotate((l.rotation||0)*Math.PI/180);
      lctx.drawImage(l.imgEl,-w/2,-hh/2,w,hh);
      lctx.restore();
    } else if(l.type==='solid'){
      lctx.fillStyle=g.solidColor||'#444';lctx.fillRect(0,0,CW,CH);
    } else if(l.type==='collage'){
      let frags=(l.placed||[]).filter(f=>f.visible).sort((a,b)=>a.zIndex-b.zIndex);
      const fc=document.createElement('canvas');fc.width=CW;fc.height=CH;
      const fctx=fc.getContext('2d');
      for(const f of frags){
        const img=await getImg(f.dataUrl);
        if(!img) continue;
        fctx.save();fctx.globalAlpha=f.opacity;
        const cx=f.x+f.w/2,cy=f.y+f.h/2;
        fctx.translate(cx,cy);fctx.rotate((f.rotation||0)*Math.PI/180);
        if(f.flipped) fctx.scale(-1,1);
        if(f.borderRadius>0){fctx.beginPath();fctx.roundRect(-f.w/2,-f.h/2,f.w,f.h,f.borderRadius);fctx.clip();}
        fctx.drawImage(img,-f.w/2,-f.h/2,f.w,f.h);
        fctx.restore();
      }
      lctx.filter=combined;lctx.drawImage(fc,0,0);lctx.filter='none';
    } else { continue; }

    // Export-only optical FX (post-grade, per layer)
    if(g.lutData) applyLUT(lctx,CW,CH,g.lutData);
    if(g.vignette) drawVignette(lctx,CW,CH,g.vignette);
    if(g.grain)    drawGrain(lctx,CW,CH,g.grain);
    if(g.chromAb)  drawChromAb(lctx,CW,CH,g.chromAb);
    if(g.glow>0)   drawGlow(lctx,CW,CH,g.glow);

    ctx.save();
    ctx.globalAlpha=(g.opacity??100)/100;
    ctx.globalCompositeOperation=(g.blendMode&&g.blendMode!=='normal')?g.blendMode:'source-over';
    ctx.drawImage(lc,0,0);
    ctx.restore();
  }
  ctx.restore();
}

// ══════════════════════════════════════════════════════════════════════════════
// LAYOUT COMPOSERS
// ══════════════════════════════════════════════════════════════════════════════
function composeDasz(fragments,cw,ch){
  const placed=[];const get=(lbl,fi=0)=>fragments.find(f=>f.label===lbl)||fragments[fi];
  const rot=()=>(Math.random()-.5)*9;const jit=(v,r=.03)=>v+(Math.random()-.5)*cw*r;
  placed.push({...get('Forehead',6),id:uid(),x:jit(cw*.18),y:jit(ch*.03,.015),w:cw*.62,h:ch*.19,rotation:rot(),zIndex:1});
  placed.push({...get('Left Half',8),id:uid(),x:jit(cw*.02,.02),y:jit(ch*.23),w:cw*.21,h:ch*.40,rotation:rot(),zIndex:2});
  placed.push({...get('Left Eye',0),id:uid(),x:jit(cw*.21),y:jit(ch*.27),w:cw*.24,h:ch*.19,rotation:rot(),zIndex:4});
  placed.push({...get('Right Eye',1),id:uid(),x:jit(cw*.38),y:jit(ch*.21),w:cw*.46,h:ch*.30,rotation:rot(),zIndex:8});
  placed.push({...get('Right Half',9),id:uid(),x:jit(cw*.78,.02),y:jit(ch*.26),w:cw*.20,h:ch*.32,rotation:rot(),zIndex:3,flipped:true});
  placed.push({...get('Nose',2),id:uid(),x:jit(cw*.34),y:jit(ch*.49),w:cw*.30,h:ch*.23,rotation:rot(),zIndex:5});
  placed.push({...get('Right Cheek',5),id:uid(),x:jit(cw*.74),y:jit(ch*.55),w:cw*.20,h:ch*.23,rotation:rot(),zIndex:3});
  placed.push({...get('Chin',7),id:uid(),x:jit(cw*.22),y:jit(ch*.69),w:cw*.52,h:ch*.27,rotation:rot(),zIndex:6});
  return placed;
}
function composeLayout(fragments,mode,cw,ch){
  if(mode==='dasz') return composeDasz(fragments,cw,ch);
  const n=fragments.length;const placed=[];
  if(mode==='mosaic'){
    const cols=Math.ceil(Math.sqrt(n)),rows=Math.ceil(n/cols);const cW=cw/cols,cH=ch/rows;
    fragments.forEach((f,i)=>{const sc=.82+Math.random()*.22,w=cW*sc,hh=cH*sc,col=i%cols,row=Math.floor(i/cols);
      placed.push({...f,id:uid(),x:col*cW+(cW-w)/2,y:row*cH+(cH-hh)/2,w,h:hh,rotation:(Math.random()-.5)*10,zIndex:i});});
  } else if(mode==='editorial'){
    const cx=cw/2,cy=ch/2;
    fragments.forEach((f,i)=>{const a=(i/n)*Math.PI*2-Math.PI/2,r=Math.min(cw,ch)*.28,sz=75+Math.random()*110;
      placed.push({...f,id:uid(),x:cx+Math.cos(a)*r-sz/2,y:cy+Math.sin(a)*r-sz/2,w:sz,h:sz,rotation:(Math.random()-.5)*22,zIndex:i});});
  } else if(mode==='cubist'){
    fragments.forEach((f,i)=>{const sz=65+Math.random()*160;
      placed.push({...f,id:uid(),x:Math.random()*(cw-sz),y:Math.random()*(ch-sz),w:sz,h:sz,rotation:(Math.random()-.5)*50,zIndex:i});});
  } else if(mode==='symmetry'){
    const half=Math.ceil(n/2);
    fragments.slice(0,half).forEach((f,i)=>{const yp=(i/half)*ch*.85+ch*.05,sz=72+Math.random()*80;
      placed.push({...f,id:uid(),x:cw*.06,y:yp,w:sz,h:sz,rotation:0,zIndex:i});
      placed.push({...fragments[i%n],id:uid(),x:cw*.94-sz,y:yp,w:sz,h:sz,rotation:0,flipped:true,zIndex:i+half});});
  } else if(mode==='gallery'){
    const ms=Math.min(cw,ch)*.52;
    placed.push({...fragments[0],id:uid(),x:cw/2-ms/2,y:ch/2-ms/2,w:ms,h:ms,rotation:0,zIndex:10});
    const pos=[[.04,.04],[.72,.04],[.04,.72],[.72,.72],[.38,.02],[.38,.86],[.02,.38],[.86,.38],[.20,.02],[.58,.02]];
    fragments.slice(1).forEach((f,i)=>{const sz=50+Math.random()*60,[px,py]=pos[i%pos.length];
      placed.push({...f,id:uid(),x:px*cw,y:py*ch,w:sz,h:sz,rotation:(Math.random()-.5)*18,zIndex:i});});
  } else {
    fragments.forEach((f,i)=>{const sz=45+Math.random()*210;
      placed.push({...f,id:uid(),x:Math.random()*(cw-sz),y:Math.random()*(ch-sz),w:sz,h:sz,rotation:(Math.random()-.5)*65,zIndex:i});});
  }
  return placed;
}

// ══════════════════════════════════════════════════════════════════════════════
// APP

// ══════════════════════════════════════════════════════════════════════════════
// SPOTLIGHT — Image Element Selector (CCTV/Cybercore detail badge generator)
// ══════════════════════════════════════════════════════════════════════════════
function SpotlightEditor(){
  const [baseImg,setBaseImg]=useState(null);
  const [imgNat,setImgNat]=useState({w:1,h:1}); // natural dimensions
  const [badges,setBadges]=useState([]);
  const [selBadgeId,setSelBadgeId]=useState(null);
  const [dragging,setDragging]=useState(null); // {type:'sel'|'badge', id?, startX,startY,origX,origY,origW,origH}
  const [selRect,setSelRect]=useState(null);   // {x,y,w,h} normalized 0-1 during drag
  const containerRef=useRef();
  const imgRef=useRef();
  const idRef=useRef(0);
  const nextId=()=>{ idRef.current+=1; return idRef.current; };

  const selBadge=badges.find(b=>b.id===selBadgeId)||null;

  function loadImage(file){
    if(!file||!file.type.startsWith('image/'))return;
    const url=URL.createObjectURL(file);
    const img=new Image();
    img.onload=()=>{
      setImgNat({w:img.naturalWidth,h:img.naturalHeight});
      setBaseImg(url);
      setBadges([]);
      setSelBadgeId(null);
      setSelRect(null);
    };
    img.src=url;
  }

  // Get display bounds of the image element within container
  function getImgBounds(){
    if(!imgRef.current)return null;
    const r=imgRef.current.getBoundingClientRect();
    return r;
  }

  // Convert clientX/Y to normalized image coords
  function clientToNorm(cx,cy){
    const b=getImgBounds();
    if(!b)return {x:0,y:0};
    return {
      x:Math.max(0,Math.min(1,(cx-b.left)/b.width)),
      y:Math.max(0,Math.min(1,(cy-b.top)/b.height))
    };
  }

  function getCropUrl(badge){
    if(!baseImg)return null;
    const canvas=document.createElement('canvas');
    canvas.width=300; canvas.height=300;
    const ctx=canvas.getContext('2d');
    const img=imgRef.current;
    if(!img)return null;
    const nw=img.naturalWidth, nh=img.naturalHeight;
    ctx.drawImage(img,
      badge.selX*nw, badge.selY*nh, badge.selW*nw, badge.selH*nh,
      0,0,300,300
    );
    return canvas.toDataURL('image/png');
  }

  function createBadge(x,y,w,h){
    // Ensure positive w,h
    const bx=w<0?x+w:x, by=h<0?y+h:y;
    const bw=Math.abs(w), bh=Math.abs(h);
    if(bw<0.01||bh<0.01)return;
    const id=nextId();
    const badge={
      id, selX:bx, selY:by, selW:bw, selH:bh,
      // badge position on screen (in px relative to container)
      bx:Math.random()*200+20, by:Math.random()*100+20,
      size:180,
      shape:'square',  // 'square'|'circle'|'rounded'
      radius:12,
      borderColor:'#00ff41',
      borderWidth:2,
      bgColor:'#000000',
      bgOpacity:0,
      label:'ELEMENT',
      labelPos:'top', // 'top'|'bottom'|'none'
      labelColor:'#00ff41',
      labelSize:11,
      connectorLine:true,
    };
    setBadges(prev=>[...prev,badge]);
    setSelBadgeId(id);
    setSelRect(null);
  }

  function updateBadge(id,patch){
    setBadges(prev=>prev.map(b=>b.id===id?{...b,...patch}:b));
  }
  function deleteBadge(id){
    setBadges(prev=>prev.filter(b=>b.id!==id));
    setSelBadgeId(null);
  }

  // ── Mouse handlers for selection drawing ──
  function onImgMouseDown(e){
    if(e.button!==0)return;
    e.preventDefault();
    const n=clientToNorm(e.clientX,e.clientY);
    setSelRect({x:n.x,y:n.y,w:0,h:0,startX:n.x,startY:n.y});
    setDragging({type:'sel',startX:n.x,startY:n.y});
  }

  // Badge drag start
  function onBadgeMouseDown(e,id){
    e.stopPropagation();
    e.preventDefault();
    const badge=badges.find(b=>b.id===id);
    if(!badge)return;
    setSelBadgeId(id);
    setDragging({type:'badge',id,startX:e.clientX,startY:e.clientY,origBx:badge.bx,origBy:badge.by});
  }

  function onMouseMove(e){
    if(!dragging)return;
    if(dragging.type==='sel'){
      const n=clientToNorm(e.clientX,e.clientY);
      setSelRect({x:dragging.startX,y:dragging.startY,w:n.x-dragging.startX,h:n.y-dragging.startY,startX:dragging.startX,startY:dragging.startY});
    } else if(dragging.type==='badge'){
      const dx=e.clientX-dragging.startX;
      const dy=e.clientY-dragging.startY;
      updateBadge(dragging.id,{bx:dragging.origBx+dx,by:dragging.origBy+dy});
    }
  }

  function onMouseUp(e){
    if(dragging&&dragging.type==='sel'&&selRect){
      createBadge(selRect.x,selRect.y,selRect.w,selRect.h);
    }
    setDragging(null);
  }

  // ── Export composite ──
  function exportSpotlight(){
    const img=imgRef.current;
    if(!img)return;
    const canvas=document.createElement('canvas');
    canvas.width=img.naturalWidth;
    canvas.height=img.naturalHeight;
    const ctx=canvas.getContext('2d');
    ctx.drawImage(img,0,0);
    // TODO: render badges onto export canvas (simplified)
    const a=document.createElement('a');
    a.href=canvas.toDataURL('image/png');
    a.download='spotlight_export.png';
    a.click();
  }

  // Selection rect display coords (normalized → %)
  const selDisplay=selRect?{
    left:`${Math.min(selRect.x,selRect.x+selRect.w)*100}%`,
    top:`${Math.min(selRect.y,selRect.y+selRect.h)*100}%`,
    width:`${Math.abs(selRect.w)*100}%`,
    height:`${Math.abs(selRect.h)*100}%`,
  }:null;

  const S={
    wrap:{display:'flex',height:'calc(100vh - 46px)',background:'#0a0a0a',color:'#e0e0e0',fontFamily:'monospace',overflow:'hidden'},
    main:{flex:1,display:'flex',flexDirection:'column',overflow:'hidden',position:'relative'},
    toolbar:{padding:'8px 12px',borderBottom:'1px solid #1e1e1e',display:'flex',gap:8,alignItems:'center',background:'#111'},
    imgArea:{flex:1,overflow:'auto',display:'flex',alignItems:'center',justifyContent:'center',position:'relative',background:'repeating-conic-gradient(#111 0% 25%,#0d0d0d 0% 50%) 0 0/20px 20px'},
    imgWrap:{position:'relative',display:'inline-block',userSelect:'none'},
    img:{display:'block',maxWidth:'100%',maxHeight:'calc(100vh - 110px)',cursor:'crosshair'},
    selBox:{position:'absolute',border:'2px dashed #00ff41',boxSizing:'border-box',pointerEvents:'none',background:'rgba(0,255,65,0.07)'},
    panel:{width:260,borderLeft:'1px solid #1e1e1e',display:'flex',flexDirection:'column',background:'#111',overflow:'hidden'},
    panelHead:{padding:'10px 12px',borderBottom:'1px solid #1e1e1e',fontSize:11,letterSpacing:2,color:'#00ff41',fontWeight:700},
    badgeList:{flex:1,overflow:'auto',padding:8},
    badgeItem:{padding:'6px 8px',marginBottom:4,borderRadius:4,cursor:'pointer',border:'1px solid',fontSize:11,display:'flex',justifyContent:'space-between',alignItems:'center'},
    inspector:{borderTop:'1px solid #1e1e1e',padding:10,overflow:'auto'},
    row:{display:'flex',alignItems:'center',gap:6,marginBottom:8},
    label:{fontSize:10,color:'#888',width:80,flexShrink:0,letterSpacing:1},
    inp:{flex:1,background:'#1a1a1a',border:'1px solid #2a2a2a',color:'#e0e0e0',padding:'3px 6px',borderRadius:3,fontSize:11,fontFamily:'monospace'},
    btn:{padding:'4px 10px',background:'#1a1a1a',border:'1px solid #2a2a2a',color:'#e0e0e0',borderRadius:3,cursor:'pointer',fontSize:11,fontFamily:'monospace'},
    btnGreen:{padding:'4px 10px',background:'#00ff41',border:'none',color:'#000',borderRadius:3,cursor:'pointer',fontSize:11,fontFamily:'monospace',fontWeight:700},
    btnRed:{padding:'3px 8px',background:'transparent',border:'1px solid #c00',color:'#f00',borderRadius:3,cursor:'pointer',fontSize:10},
  };

  // Render a single badge overlay
  function BadgeOverlay({badge}){
    const cropUrl=getCropUrl(badge);
    const isSelected=badge.id===selBadgeId;
    const shapeStyle={
      width:badge.size,height:badge.size,
      borderRadius:badge.shape==='circle'?'50%':badge.shape==='rounded'?badge.radius+'px':'0px',
      border:`${badge.borderWidth}px solid ${badge.borderColor}`,
      boxSizing:'border-box',
      background:cropUrl?`url(${cropUrl}) center/cover`:`rgba(0,0,0,${badge.bgOpacity})`,
      boxShadow:isSelected?`0 0 0 1px #fff, 0 0 8px ${badge.borderColor}66`:`0 0 6px ${badge.borderColor}44`,
      overflow:'hidden',
      position:'relative',
    };

    return h('div',{
      style:{position:'absolute',left:badge.bx,top:badge.by,cursor:'grab',userSelect:'none',zIndex:isSelected?100:50},
      onMouseDown:e=>onBadgeMouseDown(e,badge.id),
      onClick:e=>{e.stopPropagation();setSelBadgeId(badge.id);},
    },
      badge.labelPos==='top'&&h('div',{style:{marginBottom:3,fontSize:badge.labelSize,color:badge.labelColor,letterSpacing:2,textTransform:'uppercase',background:'rgba(0,0,0,0.8)',padding:'2px 6px',display:'inline-block',border:`1px solid ${badge.borderColor}`,whiteSpace:'nowrap'}},badge.label),
      h('div',{style:shapeStyle}),
      badge.labelPos==='bottom'&&h('div',{style:{marginTop:3,fontSize:badge.labelSize,color:badge.labelColor,letterSpacing:2,textTransform:'uppercase',background:'rgba(0,0,0,0.8)',padding:'2px 6px',display:'inline-block',border:`1px solid ${badge.borderColor}`,whiteSpace:'nowrap'}},badge.label),
    );
  }

  // Inspector for selected badge
  function BadgeInspector(){
    if(!selBadge)return h('div',{style:{padding:12,color:'#444',fontSize:11}},'Select a badge to inspect');
    return h('div',{style:S.inspector},
      h('div',{style:{...S.row,justifyContent:'space-between',marginBottom:12}},
        h('div',{style:{fontSize:10,letterSpacing:2,color:'#888'}},`BADGE #${selBadge.id}`),
        h('button',{style:S.btnRed,onClick:()=>deleteBadge(selBadge.id)},'✕ DELETE')
      ),
      // Shape
      h('div',{style:S.row},
        h('div',{style:S.label},'SHAPE'),
        ['square','circle','rounded'].map(s=>
          h('button',{key:s,style:{...S.btn,flex:1,background:selBadge.shape===s?'#222':'#111',borderColor:selBadge.shape===s?'#00ff41':'#2a2a2a',color:selBadge.shape===s?'#00ff41':'#888'},
            onClick:()=>updateBadge(selBadge.id,{shape:s})},s)
        )
      ),
      // Size
      h('div',{style:S.row},
        h('div',{style:S.label},'SIZE'),
        h('input',{type:'range',min:80,max:400,value:selBadge.size,style:{flex:1},
          onChange:e=>updateBadge(selBadge.id,{size:+e.target.value})}),
        h('div',{style:{fontSize:10,color:'#888',width:28}},selBadge.size)
      ),
      // Border radius (only for rounded)
      selBadge.shape==='rounded'&&h('div',{style:S.row},
        h('div',{style:S.label},'RADIUS'),
        h('input',{type:'range',min:0,max:80,value:selBadge.radius,style:{flex:1},
          onChange:e=>updateBadge(selBadge.id,{radius:+e.target.value})}),
        h('div',{style:{fontSize:10,color:'#888',width:28}},selBadge.radius)
      ),
      // Border
      h('div',{style:S.row},
        h('div',{style:S.label},'BORDER W'),
        h('input',{type:'range',min:0,max:8,value:selBadge.borderWidth,style:{flex:1},
          onChange:e=>updateBadge(selBadge.id,{borderWidth:+e.target.value})}),
        h('input',{type:'color',value:selBadge.borderColor,style:{width:28,height:22,border:'none',background:'none',cursor:'pointer'},
          onChange:e=>updateBadge(selBadge.id,{borderColor:e.target.value})})
      ),
      // Label text
      h('div',{style:S.row},
        h('div',{style:S.label},'LABEL'),
        h('input',{type:'text',value:selBadge.label,style:{...S.inp},
          onChange:e=>updateBadge(selBadge.id,{label:e.target.value})})
      ),
      // Label position
      h('div',{style:S.row},
        h('div',{style:S.label},'LABEL POS'),
        ['top','bottom','none'].map(p=>
          h('button',{key:p,style:{...S.btn,flex:1,background:selBadge.labelPos===p?'#222':'#111',borderColor:selBadge.labelPos===p?'#00ff41':'#2a2a2a',color:selBadge.labelPos===p?'#00ff41':'#888'},
            onClick:()=>updateBadge(selBadge.id,{labelPos:p})},p)
        )
      ),
      // Label color + size
      h('div',{style:S.row},
        h('div',{style:S.label},'LABEL CLR'),
        h('input',{type:'color',value:selBadge.labelColor,style:{width:28,height:22,border:'none',background:'none',cursor:'pointer'},
          onChange:e=>updateBadge(selBadge.id,{labelColor:e.target.value})}),
        h('input',{type:'range',min:8,max:20,value:selBadge.labelSize,style:{flex:1},
          onChange:e=>updateBadge(selBadge.id,{labelSize:+e.target.value})}),
        h('div',{style:{fontSize:10,color:'#888',width:20}},selBadge.labelSize)
      ),
    );
  }

  return h('div',{style:S.wrap,onMouseMove,onMouseUp},
    // Main image area
    h('div',{style:S.main},
      h('div',{style:S.toolbar},
        h('label',{style:{...S.btnGreen,cursor:'pointer'}},
          '⊕ LOAD IMAGE',
          h('input',{type:'file',accept:'image/*',style:{display:'none'},onChange:e=>loadImage(e.target.files[0])})
        ),
        baseImg&&h('span',{style:{fontSize:10,color:'#666',marginLeft:8}},'Drag on image to create badge'),
        h('div',{style:{flex:1}}),
        badges.length>0&&h('button',{style:S.btn,onClick:exportSpotlight},'↓ EXPORT'),
        h('button',{style:S.btn,onClick:()=>{ setBadges([]); setSelBadgeId(null); }},'CLEAR'),
      ),
      h('div',{style:S.imgArea,ref:containerRef,position:'relative'},
        baseImg?
          h('div',{style:S.imgWrap},
            h('img',{ref:imgRef,src:baseImg,style:S.img,draggable:false,
              onMouseDown:onImgMouseDown}),
            selDisplay&&h('div',{style:{...S.selBox,...selDisplay}}),
            // Selection rect border markers (corner ticks)
            selDisplay&&h('div',{style:{...S.selBox,...selDisplay,border:'none'}},
              h('div',{style:{position:'absolute',top:-1,left:-1,width:8,height:8,borderTop:'2px solid #00ff41',borderLeft:'2px solid #00ff41'}}),
              h('div',{style:{position:'absolute',top:-1,right:-1,width:8,height:8,borderTop:'2px solid #00ff41',borderRight:'2px solid #00ff41'}}),
              h('div',{style:{position:'absolute',bottom:-1,left:-1,width:8,height:8,borderBottom:'2px solid #00ff41',borderLeft:'2px solid #00ff41'}}),
              h('div',{style:{position:'absolute',bottom:-1,right:-1,width:8,height:8,borderBottom:'2px solid #00ff41',borderRight:'2px solid #00ff41'}}),
            ),
          )
        : h('div',{style:{textAlign:'center',color:'#333'}},
            h('div',{style:{fontSize:40,marginBottom:12}},'⊡'),
            h('div',{style:{fontSize:12,letterSpacing:2}}),'LOAD AN IMAGE TO BEGIN'
          ),
        // Badge overlays rendered on top of the whole imgArea
        badges.map(b=>h(BadgeOverlay,{key:b.id,badge:b})),
      ),
    ),
    // Right panel
    h('div',{style:S.panel},
      h('div',{style:S.panelHead},'BADGES'),
      h('div',{style:S.badgeList},
        badges.length===0&&h('div',{style:{fontSize:10,color:'#333',textAlign:'center',padding:20}},'No badges yet.\nDrag on image to create one.'),
        badges.map(b=>
          h('div',{key:b.id,
            style:{...S.badgeItem,borderColor:b.id===selBadgeId?b.borderColor:'#1e1e1e',background:b.id===selBadgeId?'#1a1a1a':'transparent',color:b.id===selBadgeId?'#e0e0e0':'#666'},
            onClick:()=>setSelBadgeId(b.id)},
            h('span',null,b.label||`BADGE #${b.id}`),
            h('span',{style:{fontSize:10,color:'#444'}},b.shape[0].toUpperCase())
          )
        ),
      ),
      h(BadgeInspector),
    ),
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// DASZAGE — Composite Image Editor (newspaper collage aesthetic)
// ══════════════════════════════════════════════════════════════════════════════
const DZ_W=600, DZ_H=800;

const SCRATCH_PATTERNS=[
  {id:'lines',name:'Lines'},
  {id:'dots',name:'Dots'},
  {id:'grain',name:'Grain'},
  {id:'crumple',name:'Crumple'},
  {id:'hatch',name:'Hatch'},
  {id:'noise',name:'Noise'},
];

const DASZAGE_FONTS=[
  {id:'Impact, sans-serif',name:'Impact'},
  {id:'"Courier New", monospace',name:'Courier'},
  {id:'Georgia, serif',name:'Georgia'},
  {id:'Arial, sans-serif',name:'Arial'},
  {id:'"Times New Roman", serif',name:'Times'},
  {id:'monospace',name:'Mono'},
];

// BLEND_MODES already declared above
const DZ_BLEND_MODES=BLEND_MODES;

let dzIdCounter=0;
function makeDzEl(type,extra={}){
  dzIdCounter+=1;
  const base={
    id:dzIdCounter, type,
    x:80+(Math.random()*200|0), y:80+(Math.random()*200|0),
    w:200, h:type==='text'?60:200,
    rotation:0, opacity:1, blend:'normal', zIndex:dzIdCounter,
  };
  if(type==='text') return {...base,
    text:'EDIT THIS TEXT', fontSize:28, fontFamily:'Impact, sans-serif',
    color:'#000000', align:'left', bold:false, italic:false,
    tracking:0, lineHeight:1.2, stroke:false, strokeColor:'#ffffff', strokeWidth:2,
    ...extra};
  if(type==='image') return {...base, src:null, radius:0, ...extra};
  if(type==='scratch') return {...base,
    pattern:SCRATCH_PATTERNS[0].id, w:200, h:200,
    color:'#000000', intensity:0.5,
    ...extra};
  return base;
}

function DaszageEditor(){
  const [elements,setElements]=useState([]);
  const [selId,setSelId]=useState(null);
  const [bgType,setBgType]=useState('newspaper'); // 'newspaper'|'color'|'image'
  const [bgColor,setBgColor]=useState('#f5f0e8');
  const [bgImage,setBgImage]=useState(null);
  const [drag,setDrag]=useState(null); // {id,startX,startY,origX,origY,origW,origH,corner?}
  const canvasRef=useRef();
  const fileInputRef=useRef();
  const addFileFor=useRef(null); // which element id to replace image for

  const sel=elements.find(e=>e.id===selId)||null;
  const sorted=[...elements].sort((a,b)=>a.zIndex-b.zIndex);

  function addEl(el){ setElements(prev=>[...prev,el]); setSelId(el.id); }
  function updateEl(id,patch){ setElements(prev=>prev.map(e=>e.id===id?{...e,...patch}:e)); }
  function deleteEl(id){ setElements(prev=>prev.filter(e=>e.id!==id)); setSelId(null); }
  function bringFwd(id){
    const cur=elements.find(e=>e.id===id);
    const above=elements.filter(e=>e.zIndex>cur.zIndex).sort((a,b)=>a.zIndex-b.zIndex)[0];
    if(!above)return;
    setElements(prev=>prev.map(e=>{
      if(e.id===id) return {...e,zIndex:above.zIndex};
      if(e.id===above.id) return {...e,zIndex:cur.zIndex};
      return e;
    }));
  }
  function sendBck(id){
    const cur=elements.find(e=>e.id===id);
    const below=elements.filter(e=>e.zIndex<cur.zIndex).sort((a,b)=>b.zIndex-a.zIndex)[0];
    if(!below)return;
    setElements(prev=>prev.map(e=>{
      if(e.id===id) return {...e,zIndex:below.zIndex};
      if(e.id===below.id) return {...e,zIndex:cur.zIndex};
      return e;
    }));
  }

  function loadImageForEl(file,id){
    if(!file||!file.type.startsWith('image/'))return;
    const url=URL.createObjectURL(file);
    updateEl(id,{src:url});
  }

  // Newspaper background CSS
  function newsprint(){
    return {
      background:`
        linear-gradient(rgba(220,200,160,0.15) 1px, transparent 1px),
        linear-gradient(90deg, rgba(220,200,160,0.1) 1px, transparent 1px),
        repeating-linear-gradient(
          0deg, transparent, transparent 22px,
          rgba(100,80,50,0.12) 22px, rgba(100,80,50,0.12) 23px
        ),
        #f0e8d0
      `,
      backgroundSize:'40px 40px, 40px 40px, 100% 23px, 100% 100%',
    };
  }

  // Scratch pattern SVG
  function scratchSVG(el){
    const c=el.color||'#000', op=el.intensity||0.5;
    const w=el.w, h=el.h;
    if(el.pattern==='lines'){
      let lines='';
      for(let i=0;i<h;i+=6) lines+=`<line x1="0" y1="${i}" x2="${w}" y2="${i}" stroke="${c}" stroke-width="0.8" opacity="${op}"/>`;
      return `data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">${lines}</svg>`)}`;
    }
    if(el.pattern==='dots'){
      let dots='';
      for(let y=0;y<h;y+=8) for(let x=0;x<w;x+=8)
        if(Math.random()>0.5) dots+=`<circle cx="${x}" cy="${y}" r="1" fill="${c}" opacity="${op}"/>`;
      return `data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">${dots}</svg>`)}`;
    }
    if(el.pattern==='hatch'){
      let lines='';
      for(let i=-h;i<w+h;i+=8) lines+=`<line x1="${i}" y1="0" x2="${i+h}" y2="${h}" stroke="${c}" stroke-width="0.7" opacity="${op}"/>`;
      return `data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">${lines}</svg>`)}`;
    }
    // grain/noise/crumple — canvas-based
    const canvas=document.createElement('canvas');
    canvas.width=w; canvas.height=h;
    const ctx=canvas.getContext('2d');
    const idata=ctx.createImageData(w,h);
    const d=idata.data;
    const [rr,gg,bb]=hexToRgb(c)||[0,0,0];
    for(let i=0;i<d.length;i+=4){
      const v=Math.random();
      if(el.pattern==='grain'?v>0.85:v>0.7){
        d[i]=rr;d[i+1]=gg;d[i+2]=bb;d[i+3]=Math.floor(op*255);
      }
    }
    ctx.putImageData(idata,0,0);
    return canvas.toDataURL();
  }

  function hexToRgb(hex){
    const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);
    return [r,g,b];
  }

  // ── Drag/resize handlers ──
  function onElMouseDown(e,id,corner=null){
    e.stopPropagation(); e.preventDefault();
    const el=elements.find(el=>el.id===id); if(!el)return;
    setSelId(id);
    setDrag({id,corner,startX:e.clientX,startY:e.clientY,origX:el.x,origY:el.y,origW:el.w,origH:el.h});
  }

  function onMouseMove(e){
    if(!drag)return;
    const dx=e.clientX-drag.startX, dy=e.clientY-drag.startY;
    if(!drag.corner){
      updateEl(drag.id,{x:drag.origX+dx,y:drag.origY+dy});
    } else {
      // resize from corner
      if(drag.corner==='br') updateEl(drag.id,{w:Math.max(40,drag.origW+dx),h:Math.max(30,drag.origH+dy)});
    }
  }
  function onMouseUp(){ setDrag(null); }

  // ── Canvas export ──
  function exportDaszage(){
    const canvas=document.createElement('canvas');
    canvas.width=DZ_W; canvas.height=DZ_H;
    const ctx=canvas.getContext('2d');
    // Background
    if(bgType==='color'){
      ctx.fillStyle=bgColor; ctx.fillRect(0,0,DZ_W,DZ_H);
    } else if(bgType==='newspaper'){
      ctx.fillStyle='#f0e8d0'; ctx.fillRect(0,0,DZ_W,DZ_H);
      // Draw newspaper lines
      ctx.strokeStyle='rgba(100,80,50,0.12)'; ctx.lineWidth=1;
      for(let y=23;y<DZ_H;y+=23){ ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(DZ_W,y);ctx.stroke(); }
    } else if(bgType==='image'&&bgImage){
      const img=new Image(); img.src=bgImage;
      ctx.drawImage(img,0,0,DZ_W,DZ_H);
    }
    // Elements sorted by z
    const draws=[...elements].sort((a,b)=>a.zIndex-b.zIndex);
    draws.forEach(el=>{
      ctx.save();
      ctx.globalAlpha=el.opacity;
      ctx.globalCompositeOperation=el.blend||'source-over';
      const cx=el.x+el.w/2, cy=el.y+el.h/2;
      ctx.translate(cx,cy);
      ctx.rotate((el.rotation||0)*Math.PI/180);
      ctx.translate(-el.w/2,-el.h/2);
      if(el.type==='image'&&el.src){
        const img=new Image(); img.src=el.src;
        if(el.radius){ ctx.beginPath();ctx.roundRect(0,0,el.w,el.h,el.radius);ctx.clip(); }
        ctx.drawImage(img,0,0,el.w,el.h);
      } else if(el.type==='text'){
        ctx.font=`${el.italic?'italic ':''} ${el.bold?'bold ':''} ${el.fontSize}px ${el.fontFamily}`;
        ctx.fillStyle=el.color;
        ctx.textAlign=el.align||'left';
        if(el.stroke){ ctx.strokeStyle=el.strokeColor; ctx.lineWidth=el.strokeWidth; ctx.strokeText(el.text,0,el.fontSize); }
        ctx.fillText(el.text,0,el.fontSize);
      } else if(el.type==='scratch'){
        // draw scratch as random strokes
        ctx.strokeStyle=el.color;
        ctx.globalAlpha=el.opacity*el.intensity;
        for(let i=0;i<80;i++){
          ctx.beginPath();
          const x1=Math.random()*el.w, y1=Math.random()*el.h;
          ctx.moveTo(x1,y1);
          ctx.lineTo(x1+Math.random()*40-20,y1+Math.random()*40-20);
          ctx.lineWidth=Math.random()*1.5;
          ctx.stroke();
        }
      }
      ctx.restore();
    });
    const a=document.createElement('a');
    a.href=canvas.toDataURL('image/png');
    a.download='daszage_export.png';
    a.click();
  }

  // Render element on canvas
  function ElView({el}){
    const isSelected=el.id===selId;
    const style={
      position:'absolute',
      left:el.x, top:el.y, width:el.w, height:el.type==='text'?'auto':el.h,
      transform:`rotate(${el.rotation||0}deg)`,
      opacity:el.opacity,
      mixBlendMode:el.blend||'normal',
      zIndex:el.zIndex,
      cursor:drag&&drag.id===el.id?'grabbing':'grab',
      boxSizing:'border-box',
      outline:isSelected?'1.5px dashed rgba(80,160,255,0.8)':'none',
      userSelect:'none',
    };
    let inner=null;
    if(el.type==='text'){
      inner=h('div',{style:{
        fontSize:el.fontSize,fontFamily:el.fontFamily,color:el.color,
        fontWeight:el.bold?'bold':'normal',fontStyle:el.italic?'italic':'normal',
        textAlign:el.align,letterSpacing:el.tracking+'px',lineHeight:el.lineHeight,
        WebkitTextStroke:el.stroke?`${el.strokeWidth}px ${el.strokeColor}`:'none',
        whiteSpace:'pre-wrap',wordBreak:'break-word',pointerEvents:'none',
      }},el.text);
    } else if(el.type==='image'){
      inner=el.src
        ?h('img',{src:el.src,style:{width:'100%',height:'100%',objectFit:'cover',borderRadius:el.radius,display:'block',pointerEvents:'none'}})
        :h('div',{style:{width:'100%',height:'100%',background:'#ddd',display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,color:'#888',borderRadius:el.radius,border:'1px dashed #bbb'}},'click to add image');
    } else if(el.type==='scratch'){
      const svgUrl=scratchSVG(el);
      inner=h('img',{src:svgUrl,style:{width:'100%',height:'100%',pointerEvents:'none',display:'block'}});
    }

    return h('div',{
      style,
      onMouseDown:e=>onElMouseDown(e,el.id),
      onClick:e=>{ e.stopPropagation(); setSelId(el.id);
        // Image upload on click if no src
        if(el.type==='image'&&!el.src){ addFileFor.current=el.id; fileInputRef.current&&fileInputRef.current.click(); }
      },
    },
      inner,
      // Resize handle
      isSelected&&h('div',{
        style:{position:'absolute',bottom:-4,right:-4,width:10,height:10,background:'#50a0ff',cursor:'se-resize',borderRadius:2,zIndex:1},
        onMouseDown:e=>onElMouseDown(e,el.id,'br'),
      }),
    );
  }

  // ── Inspector ──
  function Inspector(){
    if(!sel)return h('div',{style:{padding:12,color:'#555',fontSize:11}},'Select an element to edit');
    const S2={
      row:{display:'flex',alignItems:'center',gap:6,marginBottom:7},
      lbl:{fontSize:10,color:'#888',width:72,flexShrink:0,letterSpacing:1},
      inp:{flex:1,background:'#1a1a1a',border:'1px solid #2a2a2a',color:'#e0e0e0',padding:'3px 6px',borderRadius:3,fontSize:11,fontFamily:'monospace'},
      btn:{padding:'3px 8px',background:'#1a1a1a',border:'1px solid #2a2a2a',color:'#e0e0e0',borderRadius:3,cursor:'pointer',fontSize:10,fontFamily:'monospace'},
      sel:{flex:1,background:'#1a1a1a',border:'1px solid #2a2a2a',color:'#e0e0e0',padding:'3px 6px',borderRadius:3,fontSize:11,fontFamily:'monospace'},
    };
    const U=(k,v)=>updateEl(sel.id,{[k]:v});
    const SI=(k,min,max,step=1)=>h(Fragment,null,
      h('input',{type:'range',min,max,step,value:sel[k]||0,style:{flex:1},onChange:e=>U(k,+e.target.value)}),
      h('div',{style:{fontSize:10,color:'#888',width:30,textAlign:'right'}},(sel[k]||0)+(k==='opacity'||k==='intensity'?'':'')),
    );

    return h('div',{style:{padding:10,overflowY:'auto',flex:1}},
      h('div',{style:{...S2.row,justifyContent:'space-between',marginBottom:10}},
        h('div',{style:{fontSize:10,letterSpacing:2,color:'#888',textTransform:'uppercase'}},sel.type+' #'+sel.id),
        h('div',{style:{display:'flex',gap:4}},
          h('button',{style:S2.btn,onClick:()=>bringFwd(sel.id)},'▲'),
          h('button',{style:S2.btn,onClick:()=>sendBck(sel.id)},'▼'),
          h('button',{style:{...S2.btn,borderColor:'#c00',color:'#f00'},onClick:()=>deleteEl(sel.id)},'✕'),
        )
      ),
      // Position
      h('div',{style:S2.row},h('div',{style:S2.lbl},'X / Y'),
        h('input',{type:'number',value:Math.round(sel.x),style:{...S2.inp,width:50},onChange:e=>U('x',+e.target.value)}),
        h('input',{type:'number',value:Math.round(sel.y),style:{...S2.inp,width:50},onChange:e=>U('y',+e.target.value)}),
      ),
      // Size
      h('div',{style:S2.row},h('div',{style:S2.lbl},'W / H'),
        h('input',{type:'number',value:Math.round(sel.w),style:{...S2.inp,width:50},onChange:e=>U('w',+e.target.value)}),
        h('input',{type:'number',value:Math.round(sel.h),style:{...S2.inp,width:50},onChange:e=>U('h',+e.target.value)}),
      ),
      // Rotation
      h('div',{style:S2.row},h('div',{style:S2.lbl},'ROTATE'),SI('rotation',-180,180),h('div',{style:{fontSize:10,color:'#888',width:20}},'°')),
      // Opacity
      h('div',{style:S2.row},h('div',{style:S2.lbl},'OPACITY'),SI('opacity',0,1,0.01)),
      // Blend
      h('div',{style:S2.row},h('div',{style:S2.lbl},'BLEND'),
        h('select',{value:sel.blend||'normal',style:S2.sel,onChange:e=>U('blend',e.target.value)},
          DZ_BLEND_MODES.map(m=>h('option',{key:m,value:m},m))
        )
      ),
      // Type-specific
      sel.type==='text'&&h(Fragment,null,
        h('hr',{style:{border:'none',borderTop:'1px solid #1e1e1e',margin:'8px 0'}}),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'TEXT'),
          h('textarea',{value:sel.text,rows:3,style:{...S2.inp,resize:'vertical'},onChange:e=>U('text',e.target.value)})
        ),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'FONT'),
          h('select',{value:sel.fontFamily,style:S2.sel,onChange:e=>U('fontFamily',e.target.value)},
            DASZAGE_FONTS.map(f=>h('option',{key:f.id,value:f.id},f.name))
          )
        ),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'SIZE'),SI('fontSize',8,200)),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'COLOR'),h('input',{type:'color',value:sel.color,style:{width:28,height:22,border:'none',background:'none',cursor:'pointer'},onChange:e=>U('color',e.target.value)})),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'ALIGN'),
          ['left','center','right'].map(a=>h('button',{key:a,style:{...S2.btn,flex:1,borderColor:sel.align===a?'#50a0ff':'#2a2a2a',color:sel.align===a?'#50a0ff':'#888'},onClick:()=>U('align',a)},a))
        ),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'STYLE'),
          h('button',{style:{...S2.btn,flex:1,borderColor:sel.bold?'#50a0ff':'#2a2a2a',color:sel.bold?'#50a0ff':'#888'},onClick:()=>U('bold',!sel.bold)},'Bold'),
          h('button',{style:{...S2.btn,flex:1,borderColor:sel.italic?'#50a0ff':'#2a2a2a',color:sel.italic?'#50a0ff':'#888'},onClick:()=>U('italic',!sel.italic)},'Italic'),
        ),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'TRACKING'),SI('tracking',-10,30)),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'LINE HT'),SI('lineHeight',0.5,3,0.05)),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'STROKE'),
          h('button',{style:{...S2.btn,borderColor:sel.stroke?'#50a0ff':'#2a2a2a',color:sel.stroke?'#50a0ff':'#888'},onClick:()=>U('stroke',!sel.stroke)},sel.stroke?'ON':'OFF'),
          sel.stroke&&h(Fragment,null,
            h('input',{type:'color',value:sel.strokeColor,style:{width:24,height:22,border:'none',background:'none',cursor:'pointer'},onChange:e=>U('strokeColor',e.target.value)}),
            h('input',{type:'range',min:1,max:10,value:sel.strokeWidth,style:{flex:1},onChange:e=>U('strokeWidth',+e.target.value)}),
          )
        ),
      ),
      sel.type==='image'&&h(Fragment,null,
        h('hr',{style:{border:'none',borderTop:'1px solid #1e1e1e',margin:'8px 0'}}),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'IMAGE'),
          h('button',{style:{...S2.btn,flex:1},onClick:()=>{addFileFor.current=sel.id;fileInputRef.current&&fileInputRef.current.click();}},sel.src?'REPLACE':'UPLOAD')
        ),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'RADIUS'),SI('radius',0,150)),
      ),
      sel.type==='scratch'&&h(Fragment,null,
        h('hr',{style:{border:'none',borderTop:'1px solid #1e1e1e',margin:'8px 0'}}),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'PATTERN'),
          h('select',{value:sel.pattern,style:S2.sel,onChange:e=>U('pattern',e.target.value)},
            SCRATCH_PATTERNS.map(p=>h('option',{key:p.id,value:p.id},p.name))
          )
        ),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'COLOR'),h('input',{type:'color',value:sel.color||'#000000',style:{width:28,height:22,border:'none',background:'none',cursor:'pointer'},onChange:e=>U('color',e.target.value)})),
        h('div',{style:S2.row},h('div',{style:S2.lbl},'INTENSITY'),SI('intensity',0,1,0.01)),
      ),
    );
  }

  const S={
    wrap:{display:'flex',height:'calc(100vh - 46px)',background:'#0a0a0a',color:'#e0e0e0',fontFamily:'monospace',overflow:'hidden'},
    sidebar:{width:36,borderRight:'1px solid #1a1a1a',display:'flex',flexDirection:'column',alignItems:'center',padding:'8px 0',gap:6,background:'#111'},
    sBtn:{width:28,height:28,background:'#1a1a1a',border:'1px solid #2a2a2a',color:'#e0e0e0',borderRadius:4,cursor:'pointer',fontSize:14,display:'flex',alignItems:'center',justifyContent:'center'},
    canvasArea:{flex:1,overflow:'auto',display:'flex',alignItems:'flex-start',justifyContent:'center',padding:20,background:'#111'},
    canvasWrap:{position:'relative',width:DZ_W,height:DZ_H,flexShrink:0,overflow:'hidden',boxShadow:'0 4px 30px rgba(0,0,0,0.5)'},
    panel:{width:240,borderLeft:'1px solid #1a1a1a',display:'flex',flexDirection:'column',background:'#111',overflow:'hidden'},
    panelHead:{padding:'8px 10px',borderBottom:'1px solid #1e1e1e',fontSize:10,letterSpacing:2,color:'#888',fontWeight:700,display:'flex',justifyContent:'space-between',alignItems:'center'},
    elList:{maxHeight:180,overflowY:'auto',borderBottom:'1px solid #1e1e1e'},
    elItem:{padding:'5px 10px',fontSize:10,cursor:'pointer',display:'flex',gap:6,alignItems:'center'},
  };

  const bgStyle=bgType==='newspaper'?newsprint():bgType==='color'?{background:bgColor}:{background:`url(${bgImage}) center/cover`,backgroundSize:'cover'};

  return h('div',{style:S.wrap,onMouseMove,onMouseUp},
    // Tool sidebar
    h('div',{style:S.sidebar},
      h('button',{style:{...S.sBtn,title:'Add Text'},onClick:()=>addEl(makeDzEl('text')),title:'Add Text'},'T'),
      h('button',{style:S.sBtn,onClick:()=>addEl(makeDzEl('image')),title:'Add Image'},'⊡'),
      h('button',{style:S.sBtn,onClick:()=>addEl(makeDzEl('scratch')),title:'Add Scratch'},'⌁'),
      h('div',{style:{flex:1}}),
      h('button',{style:{...S.sBtn,color:'#50a0ff',borderColor:'#1a3060'},onClick:exportDaszage,title:'Export PNG'},'↓'),
    ),
    // Canvas
    h('div',{style:S.canvasArea,onClick:()=>setSelId(null)},
      h('div',{style:{...S.canvasWrap,...bgStyle},ref:canvasRef},
        sorted.map(el=>h(ElView,{key:el.id,el}))
      )
    ),
    // Right panel
    h('div',{style:S.panel},
      h('div',{style:S.panelHead},
        h('span',null,'LAYERS'),
        h('div',{style:{display:'flex',gap:3}},
          h('button',{style:{...S.sBtn,width:20,height:20,fontSize:9},onClick:()=>addEl(makeDzEl('text'))},'T'),
          h('button',{style:{...S.sBtn,width:20,height:20,fontSize:9},onClick:()=>addEl(makeDzEl('image'))},'⊡'),
          h('button',{style:{...S.sBtn,width:20,height:20,fontSize:9},onClick:()=>addEl(makeDzEl('scratch'))},'⌁'),
        )
      ),
      // Element list
      h('div',{style:S.elList},
        [...elements].reverse().map(el=>
          h('div',{key:el.id,
            style:{...S.elItem,background:el.id===selId?'#1a1a1a':'transparent',borderLeft:`2px solid ${el.id===selId?'#50a0ff':'transparent'}`},
            onClick:()=>setSelId(el.id)},
            h('span',{style:{fontSize:9,color:'#555',width:8}},{text:'T',image:'⊡',scratch:'⌁'}[el.type]),
            h('span',{style:{color:el.id===selId?'#e0e0e0':'#666',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}},
              el.type==='text'?el.text.slice(0,20):`${el.type} #${el.id}`)
          )
        ),
        elements.length===0&&h('div',{style:{padding:'12px 10px',color:'#333',fontSize:10}},'No elements yet')
      ),
      // BG controls
      h('div',{style:{padding:'8px 10px',borderBottom:'1px solid #1e1e1e'}},
        h('div',{style:{fontSize:10,color:'#555',letterSpacing:1,marginBottom:6}},'BACKGROUND'),
        h('div',{style:{display:'flex',gap:4}},
          ['newspaper','color','image'].map(t=>
            h('button',{key:t,style:{flex:1,padding:'3px 0',fontSize:9,background:bgType===t?'#222':'#111',border:`1px solid ${bgType===t?'#50a0ff':'#2a2a2a'}`,color:bgType===t?'#50a0ff':'#666',borderRadius:3,cursor:'pointer',fontFamily:'monospace'},onClick:()=>setBgType(t)},t)
          )
        ),
        bgType==='color'&&h('div',{style:{marginTop:6,display:'flex',alignItems:'center',gap:6}},
          h('span',{style:{fontSize:9,color:'#555'}},'COLOR'),
          h('input',{type:'color',value:bgColor,style:{flex:1,height:22,border:'none',background:'none',cursor:'pointer'},onChange:e=>setBgColor(e.target.value)})
        ),
        bgType==='image'&&h('label',{style:{marginTop:6,display:'block',fontSize:9,color:'#50a0ff',cursor:'pointer'}},
          'UPLOAD BG IMAGE',
          h('input',{type:'file',accept:'image/*',style:{display:'none'},onChange:e=>{const f=e.target.files[0];if(f)setBgImage(URL.createObjectURL(f));}})
        ),
      ),
      // Inspector
      h(Inspector),
    ),
    // Hidden file input for image upload
    h('input',{ref:fileInputRef,type:'file',accept:'image/*',style:{display:'none'},
      onChange:e=>{
        const f=e.target.files[0];
        if(f&&addFileFor.current) loadImageForEl(f,addFileFor.current);
        addFileFor.current=null;
      }
    }),
  );
}
function App(){
  const [appTab,setAppTab]=useState('studio');

  // ── Photo layers (multi-photo) ────────────────────────────────────────────
  // Each layer: {id, name, type:'photo'|'collage'|'solid', srcUrl, imgEl,
  //              fragments:[], placed:[], grade:{...}, x,y,w,h,
  //              blendMode, opacity, visible, locked}
  const [layers,setLayers]=useState([]);
  const [activeLayerId,setActiveLayerId]=useState(null);
  const [selectedFragId,setSelectedFragId]=useState(null);

  // ── Canvas ─────────────────────────────────────────────────────────────────
  const [canvasSizeId,setCanvasSizeId]=useState('sq_md');
  const [bgColor,setBgColor]=useState('#0f0f0f');
  const [layoutMode,setLayoutMode]=useState('mosaic');

  // ── Project / File ─────────────────────────────────────────────────────────
  const [projectName,setProjectName]=useState('Untitled Project');
  const [isEditingName,setIsEditingName]=useState(false);
  const [recentProjects,setRecentProjects]=useState(()=>{try{return JSON.parse(localStorage.getItem('daszframe_recent')||'[]');}catch(_){return[];}});
  const [lastSaved,setLastSaved]=useState(null);
  const [exportFilename,setExportFilename]=useState('');
  const [showSaveAs,setShowSaveAs]=useState(false);
  const openProjRef=useRef(null);

  // ── UI ─────────────────────────────────────────────────────────────────────
  const [leftOpen,setLeftOpen]=useState(true);
  const [rightOpen,setRightOpen]=useState(true);
  const [viewMode,setViewMode]=useState('split');
  const [rtab,setRtab]=useState('layers');
  const [ltab,setLtab]=useState('tools');
  const [isProc,setIsProc]=useState(false);
  const [procMsg,setProcMsg]=useState('');
  const [aiNote,setAiNote]=useState('');
  const [showExport,setShowExport]=useState(false);
  const [showVars,setShowVars]=useState(false);
  const [variations,setVariations]=useState([]);
  const [snapGrid,setSnapGrid]=useState(false);
  const GRID=20;

  // ── Undo/Redo ──────────────────────────────────────────────────────────────
  const [history,setHistory]=useState([]);
  const [histIdx,setHistIdx]=useState(-1);
  const skipHist=useRef(false);
  const pushHist=useCallback((newLayers)=>{
    if(skipHist.current) return;
    setHistory(prev=>[...prev.slice(0,histIdx+1),JSON.parse(JSON.stringify(newLayers))].slice(-25));
    setHistIdx(p=>Math.min(p+1,24));
  },[histIdx]);

  // Drag state
  const [dragState,setDragState]=useState(null);
  const overlayRef=useRef(null);
  const layersRef=useRef(layers);
  useEffect(()=>{layersRef.current=layers;},[layers]);
  const fileInputRef=useRef(null);
  const lutInputRef=useRef(null);

  const cs=CANVAS_SIZES.find(s=>s.id===canvasSizeId)||CANVAS_SIZES[1];
  const CW=cs.w,CH=cs.h;

  // Active layer helper
  const activeLayer=useMemo(()=>layers.find(l=>l.id===activeLayerId),[layers,activeLayerId]);
  const activeGrade=activeLayer?.grade||defaultGrade();

  // ── Update layer ───────────────────────────────────────────────────────────
  const updateLayer=useCallback((id,upd)=>{
    setLayers(prev=>{
      const next=prev.map(l=>l.id===id?{...l,...upd}:l);
      pushHist(next);return next;
    });
  },[pushHist]);

  const updateGrade=useCallback((id,gradeUpd)=>{
    setLayers(prev=>{
      const next=prev.map(l=>l.id===id?{...l,grade:{...(l.grade||defaultGrade()),...gradeUpd}}:l);
      return next; // Don't push history on every slider move
    });
  },[]);

  const commitGrade=useCallback(()=>{pushHist(layersRef.current);},[pushHist]);

  // ── Add photo layer ────────────────────────────────────────────────────────
  const addPhotoLayer=useCallback(async(file,asCollage=false)=>{
    if(!file||!file.type.startsWith('image/')) return;
    setIsProc(true);setProcMsg('Loading image…');
    const url=URL.createObjectURL(file);
    const img=new Image();
    try{
      await new Promise((res,rej)=>{img.onload=res;img.onerror=()=>rej(new Error('decode failed'));img.src=url;});
    }catch(_){
      setIsProc(false);URL.revokeObjectURL(url);
      alert('That image could not be loaded — it may be corrupt or an unsupported format.');
      return;
    }
    const name=file.name.replace(/\.[^.]+$/,'').slice(0,24);

    let frags=[],placed=[];
    if(asCollage){
      setProcMsg('Extracting face regions…');
      await tick();
      frags=FACE_REGIONS.map(r=>({
        id:uid(),label:r.label,
        thumb:extractThumb(img,r.area),
        dataUrl:extractFragment(img,r.area,400),
        visible:true,locked:false,opacity:1,style:'original',flipped:false,
      }));
      placed=composeLayout(frags,layoutMode,CW,CH);
    }

    const newLayer={
      id:uid(),name,type:asCollage?'collage':'photo',
      srcUrl:url,imgEl:img,
      fragments:frags,placed,
      x:0,y:0,w:CW,h:CH,
      grade:defaultGrade(),
      visible:true,locked:false,
    };
    setLayers(prev=>{const next=[...prev,newLayer];pushHist(next);return next;});
    setActiveLayerId(newLayer.id);
    setIsProc(false);

    // Get AI note for new layer
    try{
      const res=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({model:'claude-sonnet-4-20250514',max_tokens:120,
          messages:[{role:'user',content:`Photo editor. New ${asCollage?'collage':'photo'} layer: "${name}". Suggest a film look and one-sentence creative direction.`}]})});
      const d=await res.json();if(d.content?.[0]?.text) setAiNote(d.content[0].text);
    }catch(_){}
  },[layoutMode,CW,CH,pushHist]);

  // ── Recompose active collage layer ────────────────────────────────────────
  const recompose=useCallback(()=>{
    if(!activeLayer||activeLayer.type!=='collage'||!activeLayer.fragments.length) return;
    const newPlaced=composeLayout(activeLayer.fragments,layoutMode,CW,CH);
    updateLayer(activeLayer.id,{placed:newPlaced});
  },[activeLayer,layoutMode,CW,CH,updateLayer]);

  // ── Apply AI quick style to active layer ──────────────────────────────────
  const applyQuick=useCallback(async(q)=>{
    if(!activeLayer) return;
    updateGrade(activeLayer.id,{look:q.look});
    if(activeLayer.type==='collage'){
      setLayoutMode(q.layout);
      const newPlaced=composeLayout(activeLayer.fragments,q.layout,CW,CH);
      updateLayer(activeLayer.id,{placed:newPlaced});
    }
    setAiNote(`${q.label} style applied — ${FILM_LOOKS.find(l=>l.id===q.look)?.sub||''}`);
  },[activeLayer,CW,CH,updateLayer,updateGrade]);

  // ── Fragment drag (within collage layer) ──────────────────────────────────
  const onFragMouseDown=useCallback((e,fragId,layerId)=>{
    e.stopPropagation();
    setSelectedFragId(fragId);
    setActiveLayerId(layerId);
    const layer=layersRef.current.find(l=>l.id===layerId);
    const frag=layer?.placed.find(f=>f.id===fragId);
    if(!frag||frag.locked) return;
    const rect=overlayRef.current.getBoundingClientRect();
    setDragState({fragId,layerId,ox:e.clientX-rect.left-frag.x,oy:e.clientY-rect.top-frag.y});
  },[]);

  // ── Keyframe ops (on a fragment within a layer) ─────────────────────────────
  // A keyframe captures whichever of {x,y,rotation,scale,opacity} you choose,
  // at time `t` (ms), with an `easing` that governs the segment leading into it.



  // Frame step (when paused) — one frame = 1000/fps ms

  // Playback keyboard shortcuts (ignored while typing in a field)
  useEffect(()=>{
    const isField=(el)=>el&&/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName);
    const onKey=(e)=>{
      if(isField(e.target)) return;
      if(e.code==='Space'){
        // If a button is focused, let its own activation handle Space — don't
        // also fire the global toggle (that double-toggles and flickers).
        if(e.target&&e.target.tagName==='BUTTON') return;
      }
    };
    window.addEventListener('keydown',onKey);
    return()=>window.removeEventListener('keydown',onKey);
  },[]);

  const onMouseMove=useCallback((e)=>{
    if(!dragState) return;
    const rect=overlayRef.current.getBoundingClientRect();
    let x=e.clientX-rect.left-dragState.ox;
    let y=e.clientY-rect.top-dragState.oy;
    if(snapGrid){x=Math.round(x/GRID)*GRID;y=Math.round(y/GRID)*GRID;}
    setLayers(prev=>prev.map(l=>l.id===dragState.layerId
      ?{...l,placed:l.placed.map(f=>f.id===dragState.fragId?{...f,x,y}:f)}:l));
  },[dragState,snapGrid]);

  const onMouseUp=useCallback(()=>{
    if(dragState){ pushHist(layersRef.current); }
    setDragState(null);
  },[dragState,pushHist]);

  // Keyboard
  useEffect(()=>{
    const h=(e)=>{
      if((e.ctrlKey||e.metaKey)&&e.key==='z'&&!e.shiftKey){
        e.preventDefault();
        if(histIdx>0){skipHist.current=true;setLayers(history[histIdx-1].map(l=>({...l})));setHistIdx(p=>p-1);setTimeout(()=>{skipHist.current=false;},0);}
      }
      if((e.ctrlKey||e.metaKey)&&(e.key==='y'||(e.key==='z'&&e.shiftKey))){
        e.preventDefault();
        if(histIdx<history.length-1){skipHist.current=true;setLayers(history[histIdx+1].map(l=>({...l})));setHistIdx(p=>p+1);setTimeout(()=>{skipHist.current=false;},0);}
      }
      if(e.key==='Escape'){setSelectedFragId(null);}
    };
    window.addEventListener('keydown',h);return()=>window.removeEventListener('keydown',h);
  },[history,histIdx]);

  // ── Fragment ops ───────────────────────────────────────────────────────────
  const updateFrag=useCallback((layerId,fragId,upd)=>{
    setLayers(prev=>prev.map(l=>l.id===layerId?{...l,placed:l.placed.map(f=>f.id===fragId?{...f,...upd}:f)}:l));
  },[]);
  const deleteFrag=useCallback((layerId,fragId)=>{
    setLayers(prev=>prev.map(l=>l.id===layerId?{...l,placed:l.placed.filter(f=>f.id!==fragId)}:l));
    setSelectedFragId(null);
  },[]);
  const dupFrag=useCallback((layerId,frag)=>{
    setLayers(prev=>prev.map(l=>l.id===layerId?{...l,placed:[...l.placed,{...frag,id:uid(),x:frag.x+20,y:frag.y+20,zIndex:(frag.zIndex||0)+1}]}:l));
  },[]);
  const bringFwd=useCallback((layerId,fragId)=>{
    setLayers(prev=>prev.map(l=>{if(l.id!==layerId)return l;const mx=Math.max(...l.placed.map(f=>f.zIndex||0));return{...l,placed:l.placed.map(f=>f.id===fragId?{...f,zIndex:mx+1}:f)};}));
  },[]);
  const sendBck=useCallback((layerId,fragId)=>{
    setLayers(prev=>prev.map(l=>{if(l.id!==layerId)return l;const mn=Math.min(...l.placed.map(f=>f.zIndex||0));return{...l,placed:l.placed.map(f=>f.id===fragId?{...f,zIndex:mn-1}:f)};}));
  },[]);


  const deleteLayer=useCallback((id)=>{setLayers(prev=>{const next=prev.filter(l=>l.id!==id);if(activeLayerId===id)setActiveLayerId(next[next.length-1]?.id||null);return next;});},[activeLayerId]);
  const dupeLayer=useCallback((id)=>{const l=layersRef.current.find(x=>x.id===id);if(!l)return;const nl={...JSON.parse(JSON.stringify({...l,imgEl:undefined})),id:uid(),name:l.name+' copy',imgEl:l.imgEl};setLayers(prev=>[...prev,nl]);setActiveLayerId(nl.id);},[]);
  const moveLayerUp=useCallback((id)=>{setLayers(prev=>{const i=prev.findIndex(l=>l.id===id);if(i<=0)return prev;const n=[...prev];[n[i-1],n[i]]=[n[i],n[i-1]];return n;});},[]);
  const moveLayerDown=useCallback((id)=>{setLayers(prev=>{const i=prev.findIndex(l=>l.id===id);if(i>=prev.length-1)return prev;const n=[...prev];[n[i],n[i+1]]=[n[i+1],n[i]];return n;});},[]);

  // ── LUT import ────────────────────────────────────────────────────────────
  const importLUT=useCallback((file)=>{
    if(!file||!activeLayer) return;
    const reader=new FileReader();
    reader.onload=e=>{
      const lut=parseCube(e.target.result);
      updateGrade(activeLayer.id,{lutName:file.name,lutData:lut});
    };
    reader.readAsText(file);
  },[activeLayer,updateGrade]);

  // ── Save Project (.daszframe) ─────────────────────────────────────────────
  const saveProject=useCallback((name)=>{
    const pName=name||projectName||'Untitled Project';
    setProjectName(pName);
    // Serialize layers — imgEl can't be JSON'd. Embed the pixels as a data URL
    // so the project reloads in a fresh session (blob: URLs die on tab close).
    const serializableLayers=layers.map(l=>({
      ...l,
      imgEl:undefined,
      srcUrl:undefined,
      srcData:(l.type==='photo'||l.type==='collage')?imgElToDataURL(l.imgEl):null,
    }));
    const session={
      version:'3.0',
      name:pName,
      savedAt:new Date().toISOString(),
      canvasSizeId,bgColor,layoutMode,aiNote,
      layers:serializableLayers,
      activeLayerId,
    };
    const blob=new Blob([JSON.stringify(session)],{type:'application/json'});
    const a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download=`${pName.replace(/[^a-zA-Z0-9_\- ]/g,'').trim()||'project'}.daszframe`;
    a.click();
    setLastSaved(new Date());
    // Track in recents
    const recents=[{name:pName,date:new Date().toISOString()},...recentProjects.filter(r=>r.name!==pName)].slice(0,5);
    setRecentProjects(recents);
    try{localStorage.setItem('daszframe_recent',JSON.stringify(recents));}catch(_){}
  },[layers,projectName,canvasSizeId,bgColor,layoutMode,aiNote,activeLayerId,recentProjects]);

  // ── Open Project (.daszframe) ─────────────────────────────────────────────
  const openProject=useCallback((file)=>{
    if(!file) return;
    const reader=new FileReader();
    reader.onload=async e=>{
      try{
        const session=JSON.parse(e.target.result);
        setProjectName(session.name||'Untitled Project');
        if(session.canvasSizeId) setCanvasSizeId(session.canvasSizeId);
        if(session.bgColor)      setBgColor(session.bgColor);
        if(session.layoutMode)   setLayoutMode(session.layoutMode);
        if(session.aiNote)       setAiNote(session.aiNote);

        // Reload images from embedded data URLs (new files) or legacy blob URLs.
        const restoredLayers=await Promise.all((session.layers||[]).map(async l=>{
          const src=l.srcData||l.srcUrl;
          if((l.type==='photo'||l.type==='collage')&&src){
            try{
              const img=new Image();
              await new Promise((res,rej)=>{img.onload=res;img.onerror=rej;img.src=src;});
              return{...l,imgEl:img,srcUrl:src};
            }catch(_){return{...l,imgEl:null};}
          }
          return l;
        }));
        setLayers(restoredLayers);
        setActiveLayerId(session.activeLayerId||restoredLayers[restoredLayers.length-1]?.id||null);
        setLastSaved(new Date(session.savedAt));
      }catch(_){alert('Could not open file — it may be corrupted or from an older version.');}
    };
    reader.readAsText(file);
  },[]);

  // ── Auto-save to localStorage every 30s ──────────────────────────────────
  useEffect(()=>{
    if(!layers.length) return;
    const t=setTimeout(()=>{
      try{
        const lite={name:projectName,canvasSizeId,bgColor,layoutMode,
          layers:layers.map(l=>({...l,imgEl:undefined,
            // Only save fragment thumbnails (small), not full dataUrls (too large for localStorage)
            placed:l.placed?.map(f=>({...f,dataUrl:undefined})),
          }))
        };
        localStorage.setItem('daszframe_autosave',JSON.stringify(lite));
        localStorage.setItem('daszframe_autosave_time',new Date().toISOString());
      }catch(_){} // quota exceeded is fine
    },30000);
    return()=>clearTimeout(t);
  },[layers,projectName,canvasSizeId,bgColor,layoutMode]);

  // ── Still export (PNG / JPG / WebP) ───────────────────────────────────────
  // quality applies to jpg/webp (0..1). atTimeMs lets you export an animated
  // frame at the current playhead. Returns a Promise.
  const doExport=useCallback(async(fmt,scale,customName,quality,atTimeMs)=>{
    const baseName=(customName||projectName||'daszframe').replace(/[^a-zA-Z0-9_\- ]/g,'').trim()||'daszframe';
    const mime=fmt==='jpg'?'image/jpeg':fmt==='webp'?'image/webp':'image/png';
    const q=quality!=null?quality:0.96;
    try{
      const c=document.createElement('canvas');c.width=CW*scale;c.height=CH*scale;
      const ctx=c.getContext('2d');
      await drawComposite(ctx,scale,layers,{CW,CH,bgColor});
      const url=c.toDataURL(mime,q);
      if(!url||url==='data:,') throw new Error('Canvas produced no data (the image may be too large for this device).');
      const a=document.createElement('a');a.href=url;a.download=`${baseName}.${fmt}`;a.click();
      return true;
    }catch(err){
      // Fallback: retry at 1× if a high-res export blew the memory limit
      if(scale>1){
        try{
          const c=document.createElement('canvas');c.width=CW;c.height=CH;
          const ctx=c.getContext('2d');
          await drawComposite(ctx,1,layers,{CW,CH,bgColor});
          const a=document.createElement('a');a.href=c.toDataURL(mime,q);
          a.download=`${baseName}.${fmt}`;a.click();
          alert(`Export at ${scale}× ran out of memory, so it was saved at 1× instead.`);
          return true;
        }catch(e2){}
      }
      alert('Export failed: '+(err&&err.message?err.message:'unknown error'));
      return false;
    }
  },[layers,bgColor,CW,CH,projectName]);

  // ── Video export (WebM / GIF) ──────────────────────────────────────────────

  // ── Save grade as JSON ─────────────────────────────────────────────────────
  const saveGrade=useCallback(()=>{
    if(!activeLayer) return;
    const a=document.createElement('a');
    a.href=URL.createObjectURL(new Blob([JSON.stringify(activeLayer.grade,null,2)],{type:'application/json'}));
    a.download=`${activeLayer.name}-grade.json`;a.click();
  },[activeLayer]);

  const loadGrade=useCallback((file)=>{
    if(!file||!activeLayer) return;
    const reader=new FileReader();
    reader.onload=e=>{try{updateGrade(activeLayer.id,JSON.parse(e.target.result));}catch(_){}};
    reader.readAsText(file);
  },[activeLayer,updateGrade]);

  // ── Variations ────────────────────────────────────────────────────────────
  const genVariations=useCallback(()=>{
    if(!activeLayer||activeLayer.type!=='collage'||!activeLayer.fragments.length) return;
    const modes=['dasz','mosaic','editorial','cubist','symmetry','gallery','experimental'];
    setVariations(modes.map(m=>({mode:m,frags:composeLayout(activeLayer.fragments,m,CW,CH)})));
    setShowVars(true);
  },[activeLayer,CW,CH]);

  // Currently selected fragment (in active layer)
  const selFrag=activeLayer?.placed.find(f=>f.id===selectedFragId);

  // ── RENDER ────────────────────────────────────────────────────────────────

  // Slider component
  const Slider=({label,val,min,max,step=1,onChange,onCommit})=>
    h('div',{className:'srow'},
      h('span',{className:'srow-label'},label),
      h('input',{type:'range',min,max,step,value:val,
        onChange:e=>onChange(+e.target.value),
        onMouseUp:onCommit,onTouchEnd:onCommit}),
      h('span',{className:'srow-val'},val>0?`+${val}`:val)
    );

  // Left panel — tools + layers
  function LeftPanel(){
    return h('div',{className:`panel pl${!leftOpen?' col':''}`},
      h('div',{className:'phdr'},
        h('span',{className:'ptitle'},'Layers'),
        h('button',{className:'btn ico ghost',onClick:()=>setLeftOpen(o=>!o)},leftOpen?'←':'→')
      ),
      h('div',{className:'pclabel',onClick:()=>setLeftOpen(true)},'Layers'),
      h('div',{className:'pscroll'},
        // Add layer buttons
        h('div',{className:'sec'},
          h('div',{className:'slabel'},'Add Layer'),
          h('div',{style:{display:'flex',flexDirection:'column',gap:3}},
            h('button',{className:'btn sm full',onClick:()=>fileInputRef.current?.click()},
              h('span',{style:{fontSize:14}},'🖼'),' Add Photo Layer'),
            h('button',{className:'btn sm full',onClick:()=>{fileInputRef.current.dataset.collage='1';fileInputRef.current.click();}},
              h('span',{style:{fontSize:14}},'◈'),' Add Collage Layer'),
            h('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:3}},
              h('button',{className:'btn sm',onClick:()=>{
                const l={id:uid(),name:'Solid Color',type:'solid',srcUrl:null,imgEl:null,
                  fragments:[],placed:[],grade:{...defaultGrade(),blendMode:'normal',opacity:100},
                  visible:true,locked:false,x:0,y:0,w:CW,h:CH};
                setLayers(prev=>[...prev,l]);setActiveLayerId(l.id);
              }},'+ Solid'),
              h('button',{className:'btn sm',onClick:()=>genVariations()},'⊞ Vars')
            )
          ),
          h('input',{ref:fileInputRef,type:'file',accept:'image/*',style:{display:'none'},
            onChange:e=>{const f=e.target.files[0];const isC=e.target.dataset.collage==='1';delete e.target.dataset.collage;addPhotoLayer(f,isC);e.target.value='';}}),
        ),

        // Layer stack
        h('div',{className:'sec'},
          h('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:7}},
            h('div',{className:'slabel',style:{marginBottom:0}},`Layers (${layers.length})`),
            h('div',{style:{display:'flex',gap:3}},
              h('button',{className:'btn xs ghost',title:'Move up',onClick:()=>activeLayerId&&moveLayerUp(activeLayerId)},'↑'),
              h('button',{className:'btn xs ghost',title:'Move down',onClick:()=>activeLayerId&&moveLayerDown(activeLayerId)},'↓')
            )
          ),
          layers.length===0&&h('div',{style:{fontSize:11,color:'var(--muted)',textAlign:'center',padding:12}},'No layers yet.\nAdd a photo above.'),
          h('div',{className:'layer-list'},
            [...layers].reverse().map(l=>{
              const isActive=l.id===activeLayerId;
              const g=l.grade||defaultGrade();
              return h('div',{key:l.id,
                className:`layer-item${isActive?' active-layer sel':''}`,
                onClick:()=>{setActiveLayerId(l.id);setSelectedFragId(null);}},
                isActive&&h('div',{className:'active-mark'}),
                l.imgEl
                  ?h('img',{className:'lthumb',src:l.srcUrl,style:{opacity:l.visible?1:.35}})
                  :h('div',{className:'lthumb',style:{background:l.grade?.solidColor||'#444',display:'flex',alignItems:'center',justifyContent:'center',fontSize:14,opacity:l.visible?1:.35}},'▪'),
                h('div',{className:'linfo'},
                  h('div',{className:'lname'},l.name),
                  h('div',{className:'lmeta'},`${l.type} · ${g.blendMode||'normal'} · ${g.opacity??100}%`)
                ),
                h('span',{className:'layer-badge'},l.type==='collage'?'COL':'IMG'),
                h('div',{style:{display:'flex',gap:2,opacity:isActive?1:0,transition:'opacity .12s'}},
                  h('button',{className:'btn ico ghost',onClick:e=>{e.stopPropagation();updateLayer(l.id,{visible:!l.visible});}},l.visible?'●':'○'),
                  h('button',{className:'btn ico ghost red',onClick:e=>{e.stopPropagation();deleteLayer(l.id);}},h('span',{style:{fontSize:10}},'✕'))
                )
              );
            })
          )
        ),

        // Quick AI styles
        h('div',{className:'sec'},
          h('div',{className:'slabel'},'AI Quick Styles'),
          h('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:3}},
            AI_QUICK.map(q=>h('button',{key:q.id,className:'btn sm',
              style:{justifyContent:'flex-start',fontSize:10,gap:4},
              onClick:()=>applyQuick(q)},
              h('span',null,q.icon),q.label))
          )
        ),

        // Layout (for collage layers)
        activeLayer?.type==='collage'&&h('div',{className:'sec'},
          h('div',{className:'slabel'},'Collage Layout'),
          h('div',{className:`dchip${layoutMode==='dasz'?' on':''}`,
            onClick:()=>{setLayoutMode('dasz');setTimeout(recompose,0);}},
            h('span',{style:{fontSize:13}},'◉'),h('span',null,'DASZ'),h('span',{className:'dchip-sub'},'Signature')
          ),
          h('div',{className:'cgrid3',style:{marginTop:3}},
            LAYOUT_MODES.filter(m=>!m.sig).map(m=>h('div',{key:m.id,
              className:`chip${layoutMode===m.id?' on':''}`,
              onClick:()=>{setLayoutMode(m.id);setTimeout(recompose,0);}},
              m.icon,' ',m.label))
          ),
          h('button',{className:'btn sm full',style:{marginTop:4},onClick:recompose},'↻ Recompose')
        ),

        // AI note
        aiNote&&h('div',{className:'sec'},h('div',{className:'ai-card'},h('div',{className:'ai-badge'},'AI'),h('div',{className:'ai-text'},aiNote))),

        // Canvas
        h('div',{className:'sec'},
          h('div',{className:'slabel'},'Canvas'),
          h('div',{style:{display:'flex',flexDirection:'column',gap:3}},
            CANVAS_SIZES.map(s=>h('button',{key:s.id,className:`btn sm${canvasSizeId===s.id?' act':''}`,
              style:{justifyContent:'space-between'},onClick:()=>setCanvasSizeId(s.id)},
              h('span',null,s.label),h('span',{style:{color:'var(--muted)',fontSize:9,fontFamily:'var(--fm)'}},`${s.w}×${s.h}`)
            ))
          ),
          h('div',{style:{display:'flex',gap:5,flexWrap:'wrap',alignItems:'center',marginTop:6}},
            ['#0f0f0f','#ffffff','#f5f0e8','#e2ddd6','#1a1a2e'].map(c=>
              h('div',{key:c,onClick:()=>setBgColor(c),style:{width:18,height:18,background:c,borderRadius:2,cursor:'pointer',border:bgColor===c?'2px solid var(--acc)':'1px solid var(--b2)'}})
            ),
            h('input',{type:'color',value:bgColor,onChange:e=>setBgColor(e.target.value),style:{width:18,height:18,border:'none',background:'none',cursor:'pointer',padding:0}})
          )
        )
      )
    );
  }

  // Right panel — grade / effects / props
  function RightPanel(){
    const g=activeGrade;
    const gid=activeLayer?.id;

    return h('div',{className:`panel pr${!rightOpen?' col':''}`},
      h('div',{className:'phdr'},
        h('button',{className:'btn ico ghost',onClick:()=>setRightOpen(o=>!o)},rightOpen?'→':'←'),
        h('span',{className:'ptitle'},activeLayer?`Grade: ${activeLayer.name}`:'Grading')
      ),
      h('div',{className:'pclabel',onClick:()=>setRightOpen(true)},'Grade'),
      h('div',{className:'pscroll'},
        h('div',{className:'tabs'},
          h('div',{className:`tab${rtab==='looks'?' on':''}`,onClick:()=>setRtab('looks')},'Looks'),
          h('div',{className:`tab${rtab==='grade'?' on':''}`,onClick:()=>setRtab('grade')},'Grade'),
          h('div',{className:`tab${rtab==='fx'?' on':''}`,onClick:()=>setRtab('fx')},'FX'),
          h('div',{className:`tab${rtab==='frag'?' on':''}`,onClick:()=>setRtab('frag')},'Layer'),
        ),

        !activeLayer&&h('div',{style:{color:'var(--muted)',fontSize:11,textAlign:'center',padding:16,lineHeight:1.8}},'Select a layer\nto start grading.'),

        // ── LOOKS TAB ──────────────────────────────────────────────────────
        rtab==='looks'&&activeLayer&&h('div',null,
          h('div',{className:'sec'},
            h('div',{className:'slabel'},'Film Looks'),
            h('div',{className:'look-grid'},
              FILM_LOOKS.map(lk=>h('div',{key:lk.id,
                className:`look-card${g.look===lk.id?' on':''}`,
                onClick:()=>updateGrade(gid,{look:lk.id})},
                h('div',{className:'look-name'},lk.name),
                h('div',{className:'look-sub'},lk.sub)
              ))
            )
          ),
          g.look&&g.look!=='none'&&h('div',{className:'sec'},
            h('div',{className:'slabel'},'Look Strength'),
            h('div',{className:'srow'},
              h('span',{className:'srow-label'},'Strength'),
              h('input',{type:'range',min:0,max:100,value:g.lookStrength??100,onChange:e=>updateGrade(gid,{lookStrength:+e.target.value})}),
              h('span',{className:'srow-val'},`${g.lookStrength??100}%`)
            )
          ),
          // LUT
          h('div',{className:'sec'},
            h('div',{className:'slabel'},'LUT Import / Export'),
            g.lutName&&h('div',{className:'lut-badge',style:{marginBottom:6}},
              h('span',null,'📁'),h('span',null,g.lutName),
              h('button',{className:'btn ico ghost',onClick:()=>updateGrade(gid,{lutName:null,lutData:null})},'✕')
            ),
            h('div',{style:{display:'flex',gap:4}},
              h('label',{className:'btn sm',style:{cursor:'pointer',flex:1,justifyContent:'center'}},
                '↑ Import .cube',
                h('input',{ref:lutInputRef,type:'file',accept:'.cube',style:{display:'none'},onChange:e=>importLUT(e.target.files[0])})
              ),
              h('button',{className:'btn sm',style:{flex:1},onClick:saveGrade},'↓ Export Grade')
            ),
            h('label',{className:'btn sm full',style:{cursor:'pointer',marginTop:3,justifyContent:'center'}},
              '↑ Load Grade JSON',
              h('input',{type:'file',accept:'.json',style:{display:'none'},onChange:e=>loadGrade(e.target.files[0])})
            )
          )
        ),

        // ── GRADE TAB (node-style) ─────────────────────────────────────────
        rtab==='grade'&&activeLayer&&h('div',null,
          // Exposure node
          h('div',{className:'sec'},
            h('div',{className:'node-graph'},
              h('div',{className:'node-title'},'◈ Exposure & Tone'),
              [['Exposure',g.exposure,'exposure',-100,100],
               ['Contrast',g.contrast,'contrast',-100,100],
               ['Highlights',g.highlights,'highlights',-100,100],
               ['Shadows',g.shadows,'shadows',-100,100],
               ['Whites',g.whites,'whites',-100,100],
               ['Blacks',g.blacks,'blacks',-100,100],
              ].map(([label,val,key,mn,mx])=>
                h('div',{key:key,className:'srow'},
                  h('span',{className:'srow-label'},label),
                  h('input',{type:'range',min:mn,max:mx,step:1,value:val||0,
                    onChange:e=>updateGrade(gid,{[key]:+e.target.value}),
                    onMouseUp:commitGrade}),
                  h('span',{className:'srow-val'},(val||0)>0?`+${val||0}`:val||0)
                )
              )
            ),
            // Color node
            h('div',{className:'node-graph'},
              h('div',{className:'node-title'},'◈ Color'),
              [['Saturation',g.saturation,'saturation',-100,100],
               ['Temperature',g.temperature,'temperature',-100,100],
               ['Tint',g.tint,'tint',-100,100],
               ['Vibrance',g.vibrance,'vibrance',-100,100],
              ].map(([label,val,key,mn,mx])=>
                h('div',{key:key,className:'srow'},
                  h('span',{className:'srow-label'},label),
                  h('input',{type:'range',min:mn,max:mx,step:1,value:val||0,
                    onChange:e=>updateGrade(gid,{[key]:+e.target.value}),
                    onMouseUp:commitGrade}),
                  h('span',{className:'srow-val'},(val||0)>0?`+${val||0}`:val||0)
                )
              )
            ),
            // Lift/Gamma/Gain node
            h('div',{className:'node-graph'},
              h('div',{className:'node-title'},'◈ Lift · Gamma · Gain'),
              [['Lift',g.lift,'lift',-50,50,1],
               ['Gamma',g.gamma,'gamma',.1,2.5,.01],
               ['Gain',g.gain,'gain',.1,2.5,.01],
              ].map(([label,val,key,mn,mx,step])=>
                h('div',{key:key,className:'srow'},
                  h('span',{className:'srow-label'},label),
                  h('input',{type:'range',min:mn,max:mx,step,value:val||0,
                    onChange:e=>updateGrade(gid,{[key]:+e.target.value}),
                    onMouseUp:commitGrade}),
                  h('span',{className:'srow-val'},typeof val==='number'?val.toFixed(key==='lift'?0:2):'0')
                )
              )
            ),
          ),
          // Blend mode for the layer
          h('div',{className:'sec'},
            h('div',{className:'slabel'},'Layer Blend Mode'),
            h('div',{className:'blend-row'},
              BLEND_MODES.map(bm=>h('div',{key:bm,className:`blend-chip${(g.blendMode||'normal')===bm?' on':''}`,
                onClick:()=>updateGrade(gid,{blendMode:bm})},bm))
            )
          ),
          h('div',{className:'sec'},
            h('div',{className:'slabel'},'Layer Opacity'),
            h('div',{className:'srow'},
              h('span',{className:'srow-label'},'Opacity'),
              h('input',{type:'range',min:0,max:100,value:g.opacity??100,
                onChange:e=>updateGrade(gid,{opacity:+e.target.value})}),
              h('span',{className:'srow-val'},`${g.opacity??100}%`)
            )
          )
        ),

        // ── FX TAB ────────────────────────────────────────────────────────
        rtab==='fx'&&activeLayer&&h('div',{className:'sec'},
          h('div',{className:'node-graph'},
            h('div',{className:'node-title'},'◈ Optical Effects'),
            [['Vignette',g.vignette||0,'vignette',0,100],
             ['Film Grain',g.grain||0,'grain',0,100],
             ['Chromatic Ab.',g.chromAb||0,'chromAb',0,20],
             ['Blur',g.blur||0,'blur',0,100],
             ['Glow',g.glow||0,'glow',0,100],
             ['Clarity',g.clarity||0,'clarity',-100,100],
             ['Sharpness',g.sharpness||0,'sharpness',0,100],
            ].map(([label,val,key,mn,mx])=>
              h('div',{key:key,className:'srow'},
                h('span',{className:'srow-label'},label),
                h('input',{type:'range',min:mn,max:mx,step:1,value:val,onChange:e=>updateGrade(gid,{[key]:+e.target.value}),onMouseUp:commitGrade}),
                h('span',{className:'srow-val'},val>0?`+${val}`:val)
              )
            )
          ),
          h('div',{className:'node-graph'},
            h('div',{className:'node-title'},'◈ Background'),
            h('div',{style:{display:'flex',flexDirection:'column',gap:4}},
              h('button',{className:'btn sm full',onClick:()=>{
                // Simple BG blur — add blur to bottom-most layer
                const bottomL=layers[0];if(bottomL) updateGrade(bottomL.id,{blur:30});
              }},'Blur Background'),
              h('button',{className:'btn sm full',onClick:()=>{
                const bottomL=layers[0];if(bottomL) updateGrade(bottomL.id,{blur:0,look:'none'});
              }},'Reset Background'),
              h('button',{className:'btn sm full',onClick:()=>fileInputRef.current?.click()},'Replace Background Photo')
            )
          )
        ),

        // ── LAYER / FRAGMENT TAB ──────────────────────────────────────────
        rtab==='frag'&&activeLayer&&h('div',null,
          // Layer-level props
          h('div',{className:'sec'},
            h('div',{className:'slabel'},'Layer Transform'),
            h('div',{className:'pgrid2'},
              ['x','y'].map(p=>h('div',{key:p,className:'pfield'},
                h('div',{className:'pfield-lbl'},p.toUpperCase()),
                h('input',{type:'number',value:Math.round(activeLayer[p]||0),onChange:e=>updateLayer(activeLayer.id,{[p]:+e.target.value})})
              ))
            ),
            h('div',{className:'pgrid2'},
              ['w','h'].map(p=>h('div',{key:p,className:'pfield'},
                h('div',{className:'pfield-lbl'},p==='w'?'WIDTH':'HEIGHT'),
                h('input',{type:'number',value:Math.round(activeLayer[p]||0),onChange:e=>updateLayer(activeLayer.id,{[p]:+e.target.value})})
              ))
            ),
            h('div',{className:'srow'},
              h('span',{className:'srow-label'},'Rotation'),
              h('input',{type:'range',min:-180,max:180,step:1,value:activeLayer.rotation||0,onChange:e=>updateLayer(activeLayer.id,{rotation:+e.target.value})}),
              h('span',{className:'srow-val'},`${activeLayer.rotation||0}°`)
            ),
            h('div',{style:{display:'flex',gap:4,marginTop:4}},
              h('button',{className:'btn sm',style:{flex:1},onClick:()=>dupeLayer(activeLayer.id)},'⊕ Duplicate'),
              h('button',{className:'btn sm red',style:{flex:1},onClick:()=>deleteLayer(activeLayer.id)},'✕ Delete')
            )
          ),
          // Fragment props (if collage layer and frag selected)
          activeLayer.type==='collage'&&selFrag&&h('div',{className:'sec'},
            h('div',{className:'slabel'},'Fragment: '+selFrag.label),
            h('div',{className:'pgrid2'},
              ['x','y'].map(p=>h('div',{key:p,className:'pfield'},
                h('div',{className:'pfield-lbl'},p.toUpperCase()),
                h('input',{type:'number',value:Math.round(selFrag[p]||0),onChange:e=>updateFrag(activeLayer.id,selectedFragId,{[p]:+e.target.value})})
              ))
            ),
            h('div',{className:'pgrid2',style:{marginBottom:6}},
              ['w','h'].map(p=>h('div',{key:p,className:'pfield'},
                h('div',{className:'pfield-lbl'},p==='w'?'W':'H'),
                h('input',{type:'number',value:Math.round(selFrag[p]||0),onChange:e=>updateFrag(activeLayer.id,selectedFragId,{[p]:+e.target.value})})
              ))
            ),
            h('div',{className:'srow'},
              h('span',{className:'srow-label'},'Rotation'),
              h('input',{type:'range',min:-180,max:180,step:1,value:selFrag.rotation||0,onChange:e=>updateFrag(activeLayer.id,selectedFragId,{rotation:+e.target.value})}),
              h('span',{className:'srow-val'},`${Math.round(selFrag.rotation||0)}°`)
            ),
            h('div',{className:'srow'},
              h('span',{className:'srow-label'},'Opacity'),
              h('input',{type:'range',min:0,max:1,step:.01,value:selFrag.opacity??1,onChange:e=>updateFrag(activeLayer.id,selectedFragId,{opacity:+e.target.value})}),
              h('span',{className:'srow-val'},`${Math.round((selFrag.opacity??1)*100)}%`)
            ),
            h('div',{className:'srow'},
              h('span',{className:'srow-label'},'Radius'),
              h('input',{type:'range',min:0,max:80,step:1,value:selFrag.borderRadius||0,onChange:e=>updateFrag(activeLayer.id,selectedFragId,{borderRadius:+e.target.value})}),
              h('span',{className:'srow-val'},`${selFrag.borderRadius||0}px`)
            ),
            h('div',{style:{display:'flex',flexDirection:'column',gap:4,marginTop:4}},
              h('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:4}},
                h('button',{className:'btn sm',onClick:()=>updateFrag(activeLayer.id,selectedFragId,{flipped:!selFrag.flipped})},'↔ Flip'),
                h('button',{className:'btn sm',onClick:()=>bringFwd(activeLayer.id,selectedFragId)},'↑ Fwd')
              ),
              h('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:4}},
                h('button',{className:'btn sm',onClick:()=>dupFrag(activeLayer.id,selFrag)},'⊕ Dup'),
                h('button',{className:'btn sm red',onClick:()=>deleteFrag(activeLayer.id,selectedFragId)},'✕ Del')
              )
            )
          ),
          // Fragment list
          activeLayer.type==='collage'&&activeLayer.placed.length>0&&h('div',{className:'sec'},
            h('div',{className:'slabel'},'Fragments ({n})'.replace('{n}',activeLayer.placed.length)),
            h('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:3}},
              activeLayer.placed.slice(0,10).map(f=>
                h('div',{key:f.id,
                  style:{borderRadius:3,overflow:'hidden',border:`1px solid ${selectedFragId===f.id?'var(--acc)':'var(--b1)'}`,background:'var(--s3)',cursor:'pointer',opacity:f.visible===false?.35:1},
                  onClick:()=>setSelectedFragId(f.id)},
                  h('img',{src:f.thumb,style:{width:'100%',display:'block'}}),
                  h('div',{style:{fontSize:8,fontFamily:'var(--fm)',color:'var(--muted)',padding:'2px 4px'}},f.label)
                )
              )
            )
          )
        )
      )
    );
  }

  // Canvas stage
  function Stage(){
    const visLayers=[...layers].filter(l=>l.visible!==false);
    return h('div',{
      className:'stage',
      ref:overlayRef,
      style:{width:CW,height:CH,background:bgColor,position:'relative',overflow:'hidden'},
      onMouseMove,onMouseUp,onMouseLeave:onMouseUp,
      onClick:e=>{if(e.target===overlayRef.current){setSelectedFragId(null);}},
    },
      // Render each visible layer
      visLayers.map((l)=>{
        const g=l.grade||defaultGrade();
        const layerFilter=gradeToFilter(g);
        const lookFilter=g.look&&g.look!=='none'?lookToFilter(g.look):'none';
        const combinedFilter=[layerFilter,lookFilter!=='none'?lookFilter:''].filter(Boolean).join(' ')||'none';
        const isActive=l.id===activeLayerId;

        if(l.type==='photo'&&l.imgEl){
          return h('div',{key:l.id,
            style:{
              position:'absolute',left:l.x||0,top:l.y||0,
              width:l.w||CW,height:l.h||CH,
              transform:l.rotation?`rotate(${l.rotation}deg)`:'none',
              filter:combinedFilter,
              opacity:(g.opacity??100)/100,
              mixBlendMode:g.blendMode||'normal',
              outline:isActive?'1.5px solid rgba(232,213,163,0.4)':undefined,
              cursor:'default',
              zIndex:layers.indexOf(l),
            },
            onClick:()=>setActiveLayerId(l.id)},
            h('img',{src:l.srcUrl,style:{width:'100%',height:'100%',objectFit:'cover',display:'block',pointerEvents:'none'}})
          );
        } else if(l.type==='collage'){
          const cam=null; // cam3d/animation removed
          const sorted=[...l.placed].filter(f=>f.visible!==false).sort((a,b)=>(a.zIndex||0)-(b.zIndex||0));
          return h('div',{key:l.id,
            style:{position:'absolute',inset:0,
              filter:combinedFilter,opacity:(g.opacity??100)/100,
              mixBlendMode:g.blendMode||'normal',
              outline:isActive?'1.5px solid rgba(232,213,163,0.25)':undefined,
              zIndex:layers.indexOf(l),
            },
            onClick:()=>setActiveLayerId(l.id)},
            sorted.map(f=>{
              let rf=f;
              const zi=cam?Math.round(1000-((f.depth==null?cam.focus:f.depth)*10)):(f.zIndex||0);
              return h('div',{key:f.id,
              className:`frag-item${selectedFragId===f.id?' sel':''}`,
              style:{
                position:'absolute',left:rf.x,top:rf.y,width:rf.w,height:rf.h,
                transform:`rotate(${rf.rotation||0}deg)${f.flipped?' scaleX(-1)':''}`,
                transformOrigin:'center center',opacity:rf.opacity??1,
                zIndex:zi,
                borderRadius:f.borderRadius>0?`${f.borderRadius}px`:undefined,
                overflow:f.borderRadius>0?'hidden':undefined,
                boxShadow:f.borderStyle==='shadow'?'4px 6px 16px rgba(0,0,0,.4)':f.borderStyle==='glow'?'0 0 18px rgba(232,213,163,.5)':undefined,
                outline:(f.keyframes&&f.keyframes.length)?'1px dashed rgba(232,213,163,.35)':undefined,
              },
              onMouseDown:e=>onFragMouseDown(e,f.id,l.id)},
              h('img',{src:f.dataUrl,draggable:false})
            );})
          );
        } else if(l.type==='solid'){
          return h('div',{key:l.id,style:{position:'absolute',left:l.x||0,top:l.y||0,width:l.w||CW,height:l.h||CH,background:g.solidColor||'#444',opacity:(g.opacity??100)/100,mixBlendMode:g.blendMode||'normal',zIndex:layers.indexOf(l),cursor:'default',outline:isActive?'1.5px solid rgba(232,213,163,0.4)':undefined},onClick:()=>setActiveLayerId(l.id)});
        }
        return null;
      }),

      isProc&&h('div',{className:'lo'},h('div',{className:'lo-msg'},procMsg),h('div',{className:'lo-bar'},h('div',{className:'lo-fill'}))),

      layers.length===0&&!isProc&&h('div',{className:'empty'},
        h('div',{className:'empty-logo'},'DASZFRAME'),
        h('div',{className:'empty-sub'},'Add a photo layer to begin.\nStack multiple photos · grade each independently\nApply film looks · collage layouts · export.'),
        h('button',{className:'btn pri',style:{marginTop:14},onClick:()=>fileInputRef.current?.click()},'Add First Photo →')
      )
    );
  }



  function ExportModal(){
    const [fname,setFname]=useState(exportFilename||projectName||'daszframe');
    if(!showExport) return null;
    return h('div',{className:'modal-bg',onClick:()=>setShowExport(false)},
      h('div',{className:'modal',style:{width:340},onClick:e=>e.stopPropagation()},
        h('div',{className:'modal-title'},'Export Image'),
        h('div',{style:{marginBottom:14}},
          h('div',{style:{fontSize:10,color:'var(--muted)',fontFamily:'var(--fm)',marginBottom:6}},
            `${layers.filter(l=>l.visible).length} layers · ${CW}×${CH}`),
          h('div',{style:{marginBottom:10}},
            h('div',{style:{fontSize:11,color:'var(--text2)',marginBottom:5}},
              'Filename'),
            h('div',{style:{display:'flex',alignItems:'center',gap:6}},
              h('input',{type:'text',value:fname,
                onChange:e=>setFname(e.target.value),
                onKeyDown:e=>{if(e.key==='Enter'){doExport('png',1,fname);setShowExport(false);}},
                placeholder:'my-portrait',
                style:{flex:1,background:'var(--s3)',border:'1px solid var(--b2)',color:'var(--text)',
                  fontFamily:'var(--fb)',fontSize:13,padding:'5px 8px',borderRadius:3,outline:'none'}}),
              h('span',{style:{fontSize:11,color:'var(--muted)',fontFamily:'var(--fm)',flexShrink:0}},'.png / .jpg')
            )
          )
        ),
        h('div',{style:{fontSize:11,color:'var(--text2)',marginBottom:8}},
          'Format & Resolution'),
        h('div',{style:{display:'flex',flexDirection:'column',gap:5}},
          [['png',1,`PNG — Standard (${CW}×${CH})`,'↓'],
           ['png',2,`PNG — HD (${CW*2}×${CH*2})`,'↓'],
           ['png',4,`PNG — 4K (${CW*4}×${CH*4})`,'↓'],
           ['jpg',1,'JPG — Standard','↓'],
           ['jpg',2,'JPG — HD','↓'],
          ].map(([fmt,sc,label,icon])=>
            h('button',{key:`${fmt}${sc}`,className:'btn',
              style:{justifyContent:'space-between'},
              onClick:()=>{doExport(fmt,sc,fname||projectName);setShowExport(false);}},
              h('span',null,label),
              h('span',{style:{color:'var(--muted)',fontSize:11}},`${icon} ${fname||'daszframe'}.${fmt}`)
            )
          )
        ),
        h('div',{className:'divider',style:{margin:'12px 0'}}),
        h('button',{className:'btn',style:{width:'100%'},onClick:()=>setShowExport(false)},'Cancel')
      )
    );
  }

  // Save As modal — rename and save project file
  function SaveAsModal(){
    const [name,setName]=useState(projectName);
    if(!showSaveAs) return null;
    return h('div',{className:'modal-bg',onClick:()=>setShowSaveAs(false)},
      h('div',{className:'modal',style:{width:320},onClick:e=>e.stopPropagation()},
        h('div',{className:'modal-title'},'Save Project'),
        h('div',{style:{marginBottom:14}},
          h('div',{style:{fontSize:11,color:'var(--text2)',marginBottom:6}},'Project name'),
          h('input',{type:'text',value:name,onChange:e=>setName(e.target.value),
            autoFocus:true,
            onKeyDown:e=>{if(e.key==='Enter'&&name.trim()){saveProject(name.trim());setShowSaveAs(false);}},
            placeholder:'My Portrait Project',
            style:{width:'100%',background:'var(--s3)',border:'1px solid var(--acc)',
              color:'var(--text)',fontFamily:'var(--fb)',fontSize:14,padding:'7px 10px',
              borderRadius:3,outline:'none',marginBottom:4}}),
          h('div',{style:{fontSize:10,color:'var(--muted)',fontFamily:'var(--fm)'}},'Saves as .daszframe file — open it later to continue editing')
        ),
        // Recents
        recentProjects.length>0&&h('div',{style:{marginBottom:14}},
          h('div',{style:{fontSize:10,color:'var(--muted)',fontFamily:'var(--fm)',letterSpacing:'.08em',textTransform:'uppercase',marginBottom:6}},'Recent Projects'),
          recentProjects.map(r=>h('div',{key:r.date,
            style:{display:'flex',alignItems:'center',gap:8,padding:'5px 8px',borderRadius:3,cursor:'pointer',transition:'background .12s'},
            onMouseEnter:e=>e.currentTarget.style.background='var(--s3)',
            onMouseLeave:e=>e.currentTarget.style.background='transparent',
            onClick:()=>setName(r.name)},
            h('span',{style:{fontSize:12,flex:1}},r.name),
            h('span',{style:{fontSize:9,color:'var(--muted)',fontFamily:'var(--fm)'}},new Date(r.date).toLocaleDateString())
          ))
        ),
        h('div',{style:{display:'flex',gap:6}},
          h('button',{className:'btn',style:{flex:1},onClick:()=>setShowSaveAs(false)},'Cancel'),
          h('button',{className:'btn pri',style:{flex:1},
            disabled:!name.trim(),
            onClick:()=>{if(name.trim()){saveProject(name.trim());setShowSaveAs(false);}}},
            '↓ Save')
        )
      )
    );
  }

  // Variations modal
  function VarsModal(){
    if(!showVars) return null;
    return h('div',{className:'modal-bg',onClick:()=>setShowVars(false)},
      h('div',{className:'modal',style:{width:460},onClick:e=>e.stopPropagation()},
        h('div',{className:'modal-title'},'Layout Variations'),
        h('p',{style:{fontSize:11,color:'var(--muted)',marginBottom:12}},'Click to apply to active collage layer.'),
        h('div',{style:{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:6}},
          variations.map((v,i)=>h('div',{key:i,className:'var-thumb',onClick:()=>{
            if(activeLayer?.type==='collage'){updateLayer(activeLayer.id,{placed:v.frags});setLayoutMode(v.mode);}setShowVars(false);
          }},
            h('div',{style:{position:'relative',width:'100%',paddingBottom:'100%',background:bgColor}},
              v.frags.slice(0,7).map(f=>h('div',{key:f.id,style:{position:'absolute',left:`${(f.x/CW)*100}%`,top:`${(f.y/CH)*100}%`,width:`${(f.w/CW)*100}%`,height:`${(f.h/CH)*100}%`,transform:`rotate(${f.rotation||0}deg)`,overflow:'hidden'}},
                h('img',{src:f.thumb,style:{width:'100%',height:'100%',objectFit:'cover'}})
              )),
              h('div',{className:'var-lbl'},v.mode)
            )
          ))
        ),
        h('button',{className:'btn',style:{marginTop:12,width:'100%'},onClick:()=>setShowVars(false)},'Close')
      )
    );
  }


  const canUndo=histIdx>0,canRedo=histIdx<history.length-1;
  const selFragLayer=layers.find(l=>l.placed?.some(f=>f.id===selectedFragId));

  // Main render
  return h('div',{id:'app'},
    h('header',{className:'hdr'},
      h('div',{className:'logo'},'DASZFRAME'),
      h('div',{className:'logo-tag'},'PHOTO STUDIO'),

      h('div',{style:{display:'flex',gap:2,marginLeft:12,background:'var(--s2)',borderRadius:5,padding:2}},
        ['studio','spotlight','daszage'].map(t=>
          h('button',{key:t,
            style:{padding:'3px 14px',borderRadius:4,fontSize:11,fontFamily:'var(--fb)',fontWeight:600,
              letterSpacing:1.5,textTransform:'uppercase',cursor:'pointer',transition:'all .15s',
              background:appTab===t?'var(--acc)':'transparent',
              color:appTab===t?'#000':'var(--muted)',border:'none'},
            onClick:()=>setAppTab(t)},t)
        )
      ),

      // Editable project name in center
      h('div',{className:'hdr-center'},
        isEditingName
          ? h('input',{type:'text',value:projectName,autoFocus:true,
              style:{background:'var(--s2)',border:'1px solid var(--acc)',color:'var(--text)',
                fontFamily:'var(--fb)',fontSize:13,fontWeight:500,padding:'3px 8px',
                borderRadius:3,outline:'none',minWidth:200,textAlign:'center'},
              onChange:e=>setProjectName(e.target.value),
              onBlur:()=>setIsEditingName(false),
              onKeyDown:e=>{if(e.key==='Enter'||e.key==='Escape')setIsEditingName(false);}})
          : h('div',{
              style:{display:'flex',alignItems:'center',gap:6,cursor:'text',padding:'3px 8px',
                borderRadius:3,border:'1px solid transparent',transition:'border-color .15s'},
              onClick:()=>setIsEditingName(true),
              onMouseEnter:e=>e.currentTarget.style.borderColor='var(--b2)',
              onMouseLeave:e=>e.currentTarget.style.borderColor='transparent'},
              h('span',{style:{fontSize:13,fontWeight:500,color:'var(--text)'}},projectName),
              h('span',{style:{fontSize:10,color:'var(--muted)'}},lastSaved?`· saved ${lastSaved.toLocaleTimeString()}`:layers.length?'· unsaved':''),
              h('span',{style:{fontSize:10,color:'var(--muted)',marginLeft:2}},'✏')
            ),
        h('div',{className:'vsw',style:{marginLeft:8}},
          h('button',{className:`vbtn${viewMode==='split'?' on':''}`,onClick:()=>setViewMode('split')},'Split'),
          h('button',{className:`vbtn${viewMode==='canvas'?' on':''}`,onClick:()=>setViewMode('canvas')},'Canvas'),
          h('button',{className:`vbtn${viewMode==='full'?' on':''}`,onClick:()=>setViewMode('full')},'Full')
        )
      ),

      h('div',{className:'hdr-right'},
        // Save / Open
        h('button',{className:'btn xs ghost',title:'Open project (.daszframe)',
          onClick:()=>openProjRef.current?.click()},'↑ Open'),
        h('input',{ref:openProjRef,type:'file',accept:'.daszframe',style:{display:'none'},
          onChange:e=>{openProject(e.target.files[0]);e.target.value=''}}),
        h('button',{className:'btn xs ghost',title:'Save project',
          onClick:()=>setShowSaveAs(true)},
          layers.length?'↓ Save':'↓ Save'),
        h('div',{style:{width:1,height:14,background:'var(--b1)',margin:'0 2px'}}),
        // Undo/Redo
        h('button',{className:'btn xs ghost',disabled:!canUndo,title:'Undo (Ctrl+Z)',
          onClick:()=>{if(histIdx>0){skipHist.current=true;setLayers(history[histIdx-1].map(l=>({...l})));setHistIdx(p=>p-1);setTimeout(()=>{skipHist.current=false;},0);}}},
          '↩'),
        h('button',{className:'btn xs ghost',disabled:!canRedo,title:'Redo (Ctrl+Y)',
          onClick:()=>{if(histIdx<history.length-1){skipHist.current=true;setLayers(history[histIdx+1].map(l=>({...l})));setHistIdx(p=>p+1);setTimeout(()=>{skipHist.current=false;},0);}}},
          '↪'),
        h('div',{style:{width:1,height:14,background:'var(--b1)',margin:'0 2px'}}),
        h('button',{className:`btn xs ghost${snapGrid?' act':''}`,onClick:()=>setSnapGrid(v=>!v),title:'Snap to grid'},'⊞'),
        layers.length>0&&h(Fragment,null,
          h('button',{className:'btn xs ghost',onClick:genVariations},'Vars'),
          h('button',{className:'btn xs pri',onClick:()=>{setExportFilename(projectName);setShowExport(true);}},
            '↓ Export')
        )
      )
    ),

    appTab==='spotlight'&&h(SpotlightEditor),
    appTab==='daszage'&&h(DaszageEditor),
    appTab==='studio'&&h('div',{className:'body'},
      viewMode!=='canvas'&&h(LeftPanel),

      h('main',{className:'canvas-area',style:{display:viewMode==='full'?'none':'flex'}},
        h('div',{className:'toolbar'},
          h('span',{className:'tlabel'},activeLayer?`Active: ${activeLayer.name}`:'Canvas'),
          h('div',{className:'tsep'}),
          h('button',{className:`btn xs ghost${leftOpen?' act':''}`,onClick:()=>setLeftOpen(o=>!o)},'◧'),
          h('button',{className:`btn xs ghost${rightOpen?' act':''}`,onClick:()=>setRightOpen(o=>!o)},'◨'),
          h('div',{className:'tsep'}),
          selFrag&&selFragLayer&&h(Fragment,null,
            h('button',{className:'btn xs ghost',onClick:()=>bringFwd(selFragLayer.id,selectedFragId)},'↑'),
            h('button',{className:'btn xs ghost',onClick:()=>sendBck(selFragLayer.id,selectedFragId)},'↓'),
            h('button',{className:'btn xs ghost',onClick:()=>dupFrag(selFragLayer.id,selFrag)},'⊕'),
            h('button',{className:'btn xs ghost red',onClick:()=>deleteFrag(selFragLayer.id,selectedFragId)},'✕'),
            h('div',{className:'tsep'}),
            h('span',{className:'tlabel',style:{color:'var(--acc)'}},selFrag.label),
            h('div',{className:'tsep'}),
          ),
          h('div',{style:{flex:1}}),
          h('span',{className:'tlabel'},`${CW}×${CH} · ${layers.length} layers`)
        ),
        h('div',{className:'stage-wrap'},h(Stage)),
        h('div',{className:'sbar'},
          h('div',{className:`sdot${isProc?' pulse warn':''}`}),
          h('span',null,isProc?procMsg:`${layers.filter(l=>l.visible).length} visible · ${layers.filter(l=>l.type==='collage').length} collage`),
          activeLayer&&h(Fragment,null,h('span',null,'·'),h('span',{style:{color:'var(--acc)'}},activeLayer.name,` · ${activeLayer.grade?.look||'none'}`)),
          h('div',{style:{flex:1}}),
          canUndo&&h('span',null,`↩${histIdx}`)
        )
      ),

      viewMode==='full'&&h('div',{style:{flex:1,display:'flex',overflow:'hidden'}},
        h('div',{style:{flex:1,display:'flex',alignItems:'center',justifyContent:'center',padding:20,background:'repeating-conic-gradient(#111 0% 25%,#0d0d0d 0% 50%) 0 0/20px 20px'}},h(Stage)),
        h('div',{style:{width:280,borderLeft:'1px solid var(--b1)',overflow:'hidden',display:'flex',flexDirection:'column',background:'var(--s1)'}},h(RightPanel))
      ),

      viewMode!=='canvas'&&h(RightPanel)
    ),
    appTab==='studio'&&h(Fragment,null,h(ExportModal),h(VarsModal),h(SaveAsModal))
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(h(App));
