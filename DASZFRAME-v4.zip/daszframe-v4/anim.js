/* DASZFRAME — Animation engine (anim.js)
   Loaded via <script src="anim.js"> BEFORE app.js. Attaches window.DZANIM.
   No external libraries, no workers — CSP-safe (script-src 'self').
   Pure math (easings / sampling / paths) is decoupled from DOM so it is unit-testable.
   Video: native MediaRecorder (WebM). GIF: bundled window.gifenc (pure JS). */
(function (global) {
  'use strict';

  // ── Easing functions ───────────────────────────────────────────────────────
  // All take t in [0,1] and return eased value (may overshoot for elastic/back/bounce).
  const clamp01 = (t) => (t < 0 ? 0 : t > 1 ? 1 : t);
  const EASINGS = {
    linear: (t) => t,
    'ease-in': (t) => t * t * t,
    'ease-out': (t) => 1 - Math.pow(1 - t, 3),
    'ease-in-out': (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
    bounce: (t) => {
      const n1 = 7.5625, d1 = 2.75;
      if (t < 1 / d1) return n1 * t * t;
      if (t < 2 / d1) return n1 * (t -= 1.5 / d1) * t + 0.75;
      if (t < 2.5 / d1) return n1 * (t -= 2.25 / d1) * t + 0.9375;
      return n1 * (t -= 2.625 / d1) * t + 0.984375;
    },
    elastic: (t) => {
      if (t === 0 || t === 1) return t;
      const c4 = (2 * Math.PI) / 3;
      return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1;
    },
    'ease-in-back': (t) => { const c1 = 1.70158, c3 = c1 + 1; return c3 * t * t * t - c1 * t * t; },
  };
  const ease = (name, t) => (EASINGS[name] || EASINGS.linear)(clamp01(t));

  const lerp = (a, b, t) => a + (b - a) * t;

  // ── Keyframe sampling ───────────────────────────────────────────────────────
  // keyframes: [{ t (ms), x, y, rotation, scale, opacity, easing }] — sorted or not.
  // Returns the interpolated property bag at time `tMs`. Missing props fall back
  // to `base` so a track can animate only some properties.
  // The easing on keyframe[i] governs the segment i-1 -> i (i.e. easing-in TO it),
  // which matches how most timeline tools present it ("ease applied at this key").
  const ANIM_PROPS = ['x', 'y', 'rotation', 'scale', 'opacity'];

  function sampleKeyframes(keyframes, tMs, base) {
    base = base || {};
    if (!keyframes || keyframes.length === 0) return Object.assign({}, base);
    const kfs = keyframes.slice().sort((a, b) => a.t - b.t);
    if (tMs <= kfs[0].t) return mergeKf(base, kfs[0]);
    if (tMs >= kfs[kfs.length - 1].t) return mergeKf(base, kfs[kfs.length - 1]);
    let i = 0;
    while (i < kfs.length - 1 && kfs[i + 1].t <= tMs) i++;
    const a = kfs[i], b = kfs[i + 1];
    const span = b.t - a.t;
    const localT = span <= 0 ? 0 : (tMs - a.t) / span;
    const e = ease(b.easing || 'linear', localT); // easing belongs to the incoming key
    const out = Object.assign({}, base);
    for (const p of ANIM_PROPS) {
      const av = a[p], bv = b[p];
      if (av == null && bv == null) continue;            // neither key sets it
      const from = av != null ? av : (base[p] != null ? base[p] : bv);
      const to = bv != null ? bv : (base[p] != null ? base[p] : av);
      out[p] = lerp(from, to, e);
    }
    return out;
  }
  function mergeKf(base, kf) {
    const out = Object.assign({}, base);
    for (const p of ANIM_PROPS) if (kf[p] != null) out[p] = kf[p];
    return out;
  }

  // ── Path sampling ───────────────────────────────────────────────────────────
  const linePoint = (p0, p1, t) => ({ x: lerp(p0.x, p1.x, t), y: lerp(p0.y, p1.y, t) });
  const cubicBezierPoint = (p0, c1, c2, p1, t) => {
    const mt = 1 - t, mt2 = mt * mt, t2 = t * t;
    const a = mt2 * mt, b = 3 * mt2 * t, c = 3 * mt * t2, d = t2 * t;
    return { x: a * p0.x + b * c1.x + c * c2.x + d * p1.x, y: a * p0.y + b * c1.y + c * c2.y + d * p1.y };
  };
  // Freehand: array of {x,y}; sample by normalized arc-length so motion is even.
  function freehandPoint(points, t) {
    if (!points || points.length === 0) return { x: 0, y: 0 };
    if (points.length === 1) return { x: points[0].x, y: points[0].y };
    const segLen = [];
    let total = 0;
    for (let i = 1; i < points.length; i++) {
      const d = Math.hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y);
      segLen.push(d); total += d;
    }
    if (total === 0) return { x: points[0].x, y: points[0].y };
    let target = clamp01(t) * total, acc = 0;
    for (let i = 0; i < segLen.length; i++) {
      if (acc + segLen[i] >= target) {
        const lt = segLen[i] === 0 ? 0 : (target - acc) / segLen[i];
        return linePoint(points[i], points[i + 1], lt);
      }
      acc += segLen[i];
    }
    return { x: points[points.length - 1].x, y: points[points.length - 1].y };
  }
  // path: { type:'line'|'bezier'|'freehand', from, to, c1, c2, points, easing }
  function pathPoint(path, t) {
    const e = ease(path.easing || 'linear', t);
    if (path.type === 'line') return linePoint(path.from, path.to, e);
    if (path.type === 'bezier') return cubicBezierPoint(path.from, path.c1, path.c2, path.to, e);
    if (path.type === 'freehand') return freehandPoint(path.points, e);
    return { x: 0, y: 0 };
  }
  // Convert a path into N position keyframes spanning [t0,t1] — lets paths and
  // explicit keyframes share one playback code path.
  function pathToKeyframes(path, t0, t1, samples) {
    samples = samples || 24;
    const out = [];
    for (let i = 0; i <= samples; i++) {
      const u = i / samples;
      const pt = pathPoint(path, u);
      out.push({ t: lerp(t0, t1, u), x: pt.x, y: pt.y, easing: 'linear' });
    }
    return out;
  }

  // ── Camera / dolly-zoom projection ──────────────────────────────────────────
  // Pinhole model: a plane at world depth z projects with scale
  //   s = (focus - camZ) / (z - camZ)
  // about the principal point (image centre). Animating camZ while holding the
  // focus plane at s=1 reproduces the dolly-zoom ("Vertigo") warp: near and far
  // fragments scale apart while the subject stays put.
  function cameraZAt(cam, tMs) {
    const u = clamp01((cam.durationMs ? tMs / cam.durationMs : 0));
    return lerp(cam.camZ0, cam.camZ1, ease(cam.easing || 'ease-in-out', u));
  }
  function dollyScale(z, focus, camZ) {
    let denom = z - camZ;
    if (Math.abs(denom) < 1e-3) denom = denom < 0 ? -1e-3 : 1e-3;
    return (focus - camZ) / denom;
  }
  // Reproject a resolved transform {x,y,w,h} for a fragment at depth `z`.
  function projectByCamera(out, z, cam, tMs) {
    const camZ = cameraZAt(cam, tMs);
    const s = dollyScale(z != null ? z : cam.focus, cam.focus, camZ);
    const cx = cam.CW / 2, cy = cam.CH / 2;
    const ccx = out.x + out.w / 2, ccy = out.y + out.h / 2;
    const nW = out.w * s, nH = out.h * s;
    out.x = cx + (ccx - cx) * s - nW / 2;
    out.y = cy + (ccy - cy) * s - nH / 2;
    out.w = nW; out.h = nH;
    out.camScale = s;
    return out;
  }

  // ── Per-fragment resolver ───────────────────────────────────────────────────
  // Given a fragment with optional .keyframes / .motionPath, return the effective
  // {x,y,w,h,rotation,opacity,flipped,...} at time tMs. `scale` multiplies w/h
  // about the fragment centre so position stays stable. If `cam` (a dolly-zoom
  // camera) is supplied and enabled, the result is reprojected by the fragment's
  // depth so the whole collage shares one camera move.
  function resolveFragAt(frag, tMs, cam) {
    const base = {
      x: frag.x, y: frag.y, rotation: frag.rotation || 0,
      scale: 1, opacity: frag.opacity != null ? frag.opacity : 1,
    };
    let kfs = frag.keyframes ? frag.keyframes.slice() : [];
    if (frag.motionPath && frag.motionPath.type) {
      const pkf = pathToKeyframes(
        frag.motionPath,
        frag.motionPath.startMs || 0,
        frag.motionPath.endMs || 1000,
        frag.motionPath.samples || 24
      );
      // Position from path; merge any non-position keys (rotation/scale/opacity) on top.
      kfs = pkf.concat(kfs.map((k) => ({ t: k.t, rotation: k.rotation, scale: k.scale, opacity: k.opacity, easing: k.easing })));
    }
    const s = sampleKeyframes(kfs, tMs, base);
    const scale = s.scale != null ? s.scale : 1;
    const w = frag.w * scale, h = frag.h * scale;
    const out = {
      x: (s.x != null ? s.x : frag.x) - (w - frag.w) / 2,
      y: (s.y != null ? s.y : frag.y) - (h - frag.h) / 2,
      w, h,
      rotation: s.rotation != null ? s.rotation : (frag.rotation || 0),
      opacity: s.opacity != null ? s.opacity : (frag.opacity != null ? frag.opacity : 1),
      flipped: !!frag.flipped,
      borderRadius: frag.borderRadius || 0,
      dataUrl: frag.dataUrl,
      zIndex: frag.zIndex || 0,
      depth: frag.depth != null ? frag.depth : (cam ? cam.focus : null),
      visible: frag.visible !== false,
    };
    if (cam && cam.enabled) projectByCamera(out, out.depth, cam, tMs);
    return out;
  }

  // ── WebM recorder via MediaRecorder ─────────────────────────────────────────
  // drawFrameFn(tMs) must paint `canvas` for the given time. Returns a Blob.
  function pickWebmMime() {
    const cands = ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];
    if (typeof MediaRecorder === 'undefined') return null;
    return cands.find((m) => MediaRecorder.isTypeSupported(m)) || null;
  }

  async function recordWebM(canvas, opts) {
    const fps = opts.fps || 30;
    const durationMs = opts.durationMs;
    const onProgress = opts.onProgress || (() => {});
    const mime = pickWebmMime();
    if (!mime) throw new Error('WebM recording is not supported in this browser.');

    const stream = canvas.captureStream(fps);
    const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: opts.bitrate || 8e6 });
    const chunks = [];
    rec.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };

    const done = new Promise((res, rej) => {
      rec.onstop = () => res(new Blob(chunks, { type: 'video/webm' }));
      rec.onerror = (e) => rej(e.error || new Error('MediaRecorder error'));
    });

    rec.start();
    const frameMs = 1000 / fps;
    const totalFrames = Math.max(1, Math.round(durationMs / frameMs));
    // Drive frames in real time so captureStream samples each painted frame.
    for (let f = 0; f <= totalFrames; f++) {
      const tMs = Math.min(durationMs, f * frameMs);
      await opts.drawFrameFn(tMs);
      onProgress(f / totalFrames, f, totalFrames);
      await new Promise((r) => setTimeout(r, frameMs)); // pace to wall-clock
    }
    rec.requestData && rec.requestData();
    rec.stop();
    return done;
  }

  // ── GIF encoder via bundled gifenc ──────────────────────────────────────────
  async function recordGIF(canvas, opts) {
    if (!global.gifenc) throw new Error('gifenc.js is not loaded.');
    const { GIFEncoder, quantize, applyPalette } = global.gifenc;
    const fps = opts.fps || 15;                 // GIFs look fine and stay small at <=20fps
    const durationMs = opts.durationMs;
    const maxColors = opts.colors || 256;
    const onProgress = opts.onProgress || (() => {});
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;
    const frameMs = 1000 / fps;
    const delay = Math.round(frameMs);
    const totalFrames = Math.max(1, Math.round(durationMs / frameMs));
    const enc = GIFEncoder();
    for (let f = 0; f <= totalFrames; f++) {
      const tMs = Math.min(durationMs, f * frameMs);
      await opts.drawFrameFn(tMs);
      const { data } = ctx.getImageData(0, 0, W, H);
      const palette = quantize(data, maxColors);
      const index = applyPalette(data, palette);
      enc.writeFrame(index, W, H, { palette, delay });
      onProgress(f / totalFrames, f, totalFrames);
      await new Promise((r) => setTimeout(r, 0)); // yield so the UI can repaint progress
    }
    enc.finish();
    return new Blob([enc.bytes()], { type: 'image/gif' });
  }

  // ── Estimate (rough) — for the preview panel ────────────────────────────────
  function estimateBytes(fmt, W, H, fps, durationMs, bitrate) {
    const secs = durationMs / 1000;
    if (fmt === 'webm') return ((bitrate || 8e6) / 8) * secs;
    if (fmt === 'gif') return W * H * (fps * secs) * 0.18; // ~0.18 byte/px/frame after LZW, rough
    return 0;
  }

  global.DZANIM = {
    EASINGS, ease, lerp, clamp01, ANIM_PROPS,
    sampleKeyframes, mergeKf,
    linePoint, cubicBezierPoint, freehandPoint, pathPoint, pathToKeyframes,
    resolveFragAt, cameraZAt, dollyScale, projectByCamera,
    recordWebM, recordGIF, pickWebmMime, estimateBytes,
  };
})(typeof window !== 'undefined' ? window : globalThis);
