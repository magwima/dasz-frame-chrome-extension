# DASZFRAME v4 — Photo Studio

Chrome Extension · Manifest V3

## What's new in v4

### Removed
- ~~Video export~~ (WebM/GIF rendering)
- ~~Animation timeline~~ (keyframes, playhead, motion paths)

### Added

#### ⊡ Spotlight — Image Element Selector
Inspired by CCTV/cybercore surveillance aesthetics.

1. Load any image
2. **Click + drag** on the image to select an area
3. A floating **detail badge** is automatically generated — a cropped view of the selected region
4. Drag badges freely anywhere on the canvas
5. Per-badge controls:
   - **Shape**: square / circle / rounded
   - **Size** and border radius
   - **Border** color and width
   - **Label** text, position (top/bottom/none), color, size
6. Create as many badges as needed
7. Export as PNG

#### 🗞 Daszage — Composite Editor
Newspaper collage aesthetic, fully drag-and-drop.

- **Backgrounds**: newspaper (lined paper texture), solid color, or uploaded image
- **Add elements** via sidebar or layer panel:
  - **T** — Text block (font, size, color, bold/italic, tracking, line-height, stroke)
  - **⊡** — Image (upload, resize, rounded corners, blend mode)
  - **⌁** — Scratch / distressed texture (lines, dots, grain, crumple, hatch, noise; color, intensity)
- **Drag** any element to reposition
- **Resize** via corner handle
- **Rotate** via inspector
- **Z-order**: ▲ / ▼ buttons in inspector
- **Blend modes**: multiply, screen, overlay, and more
- **Export** as PNG (600×800px)

## How to install

1. Go to `chrome://extensions`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked**
4. Select the `daszframe-v4` folder

## Tab navigation

The header now has three tabs:

| Tab | Description |
|-----|-------------|
| **STUDIO** | Original multi-layer photo editor |
| **SPOTLIGHT** | CCTV-style element selector + badge generator |
| **DASZAGE** | Newspaper collage compositor |
